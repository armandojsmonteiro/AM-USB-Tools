package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(6, 19, 37));
        window.setNavigationBarColor(Color.rgb(6, 19, 37));
        setContentView(new HomeView());
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final String[] items = {
            "Dispositivo USB",
            "Informação do dispositivo",
            "Formatar USB",
            "Backup e Restauro",
            "Ficheiros",
            "Configurações"
        };

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setOnClickListener(v -> Toast.makeText(MainActivity.this, "AM USB Tools", Toast.LENGTH_SHORT).show());
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth();
            final float h = getHeight();

            // Fundo em gradiente, mantendo a área visual completa.
            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(4, 15, 31), Color.rgb(24, 79, 143), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Zona segura superior para não deixar o relógio do sistema sobrepor o cabeçalho.
            final float topSafe = 42;
            final float side = Math.max(20, w * 0.035f);

            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(Math.max(22, w * 0.034f));
            p.setColor(Color.WHITE);
            c.drawText("AM USB Tools", side, topSafe + 2, p);

            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(Math.max(12, w * 0.019f));
            p.setColor(Color.rgb(180, 201, 225));
            c.drawText("Ferramentas USB para Android", side, topSafe + 23, p);

            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(9);
            p.setColor(Color.rgb(112, 151, 196));
            c.drawText("V10", w - 31, topSafe + 2, p);

            // Cartões mais compactos e com proporção semelhante a uma aplicação profissional.
            final float left = Math.max(18, w * 0.028f);
            final float right = w - left;
            final float menuTop = topSafe + 58;
            final float bottomLimit = h - 105;
            final float gap = Math.max(10, Math.min(14, h * 0.009f));
            final float preferredHeight = Math.max(62, Math.min(72, h * 0.055f));
            final float available = bottomLimit - menuTop;
            final float totalNeeded = preferredHeight * items.length + gap * (items.length - 1);
            final float bh = totalNeeded <= available ? preferredHeight : (available - gap * (items.length - 1)) / items.length;

            for (int i = 0; i < items.length; i++) {
                final float top = menuTop + i * (bh + gap);
                r.set(left, top, right, top + bh);

                p.setShadowLayer(8, 0, 3, Color.argb(75, 0, 0, 0));
                p.setColor(Color.argb(218, 7, 28, 53));
                c.drawRoundRect(r, 14, 14, p);
                p.clearShadowLayer();

                // Pequeno detalhe lateral, sem dominar o cartão.
                p.setColor(Color.rgb(45, 126, 226));
                c.drawRoundRect(left, top + 11, left + 4, top + bh - 11, 2, 2, p);

                final float iconX = left + 30;
                final float iconY = top + bh / 2;
                drawIcon(c, iconX, iconY, i);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(Math.max(16, Math.min(19, w * 0.026f)));
                p.setColor(Color.rgb(246, 249, 253));
                c.drawText(items[i], left + 57, iconY + 6, p);

                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(24);
                p.setColor(Color.rgb(145, 181, 218));
                c.drawText("›", right - 29, iconY + 8, p);
            }

            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(8);
            p.setColor(Color.rgb(96, 132, 174));
            c.drawText("AM USB Tools", side, h - 20, p);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(29, 82, 148));
            c.drawCircle(cx, cy, 15, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.0f);
            p.setColor(Color.rgb(205, 228, 250));

            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - 4, 3.5f, p);
                    c.drawLine(cx, cy, cx, cy + 8, p);
                    c.drawLine(cx, cy + 3, cx - 6, cy - 2, p);
                    c.drawLine(cx, cy + 3, cx + 6, cy - 2, p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, 8, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - 4, 1.5f, p);
                    c.drawRect(cx - 1.2f, cy - 1, cx + 1.2f, cy + 6, p);
                    break;
                case 2:
                    c.drawRect(cx - 8, cy - 7, cx + 8, cy + 7, p);
                    c.drawLine(cx - 5, cy - 2, cx + 5, cy - 2, p);
                    c.drawLine(cx - 5, cy + 2, cx + 5, cy + 2, p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - 8, cy - 8, cx + 8, cy + 8), 35, 285, false, p);
                    c.drawLine(cx + 5, cy - 7, cx + 9, cy - 7, p);
                    c.drawLine(cx + 8, cy - 7, cx + 8, cy - 3, p);
                    break;
                case 4:
                    r.set(cx - 9, cy - 7, cx + 9, cy + 8);
                    c.drawRoundRect(r, 2, 2, p);
                    c.drawLine(cx - 6, cy - 2, cx + 6, cy - 2, p);
                    break;
                default:
                    c.drawCircle(cx, cy, 4.5f, p);
                    c.drawCircle(cx, cy, 9, p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * 2 * i / 8.0;
                        float x1 = cx + (float) Math.cos(a) * 9;
                        float y1 = cy + (float) Math.sin(a) * 9;
                        float x2 = cx + (float) Math.cos(a) * 12;
                        float y2 = cy + (float) Math.sin(a) * 12;
                        c.drawLine(x1, y1, x2, y2, p);
                    }
                    break;
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
