package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int WHITE = Color.rgb(245, 247, 250);
    private final int MUTED = Color.rgb(190, 198, 210);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 22, 22, 22);
        root.setBackgroundResource(R.drawable.bg);

        TextView title = text("⚙  AM USB TOOLS", 25, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, 64));
        root.addView(text("Ferramentas profissionais para dispositivos USB", 14, false));

        section(root, "GESTÃO DE DISCOS");
        button(root, "Formatar USB", "FAT16 • FAT32 • exFAT • NTFS • Ext2 • Ext3 • Ext4");
        button(root, "Assistente de partição", "Gestão avançada de partições para dispositivos USB");
        button(root, "Desfragmentador USB", "Otimização e verificação de unidades compatíveis");
        button(root, "Limpar USB", "Apagar dados e partições de um dispositivo USB");
        button(root, "Backup / Restauração", "Cópia completa ou restauração do dispositivo USB");

        section(root, "FERRAMENTAS DE JOGOS");
        button(root, "Verificar USB", "Diagnóstico e verificação do dispositivo");
        button(root, "Informações USB", "Capacidade, sistema de ficheiros e estado");

        setContentView(root);
    }

    private TextView text(String value, float size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(WHITE);
        v.setTextSize(size);
        v.setPadding(8, 8, 8, 8);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void section(LinearLayout root, String value) {
        TextView v = text(value, 18, true);
        v.setPadding(8, 22, 8, 10);
        root.addView(v);
    }

    private void button(LinearLayout root, String title, String description) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 15, 18, 15);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(25, 31, 43));
        background.setCornerRadius(20);
        card.setBackground(background);

        card.addView(text(title, 18, true));
        TextView d = text(description, 13, false);
        d.setTextColor(MUTED);
        card.addView(d);
        card.setOnClickListener(v -> Toast.makeText(this, title + " — função em desenvolvimento", Toast.LENGTH_SHORT).show());

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 5, 0, 5);
        root.addView(card, p);
    }
}
