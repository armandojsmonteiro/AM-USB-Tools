package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int topInset = 0;
    private int bottomInset = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(6, 18, 36));
        window.setNavigationBarColor(Color.rgb(6, 18, 36));
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        }

        HomeView home = new HomeView();
        home.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = 24;
                bottomInset = 48;
            }
            v.invalidate();
            return insets;
        });
        setContentView(home);
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final String[] items = {
            "Dispositivo USB",
            "Informação do dispositivo",
            "Formatar USB",
            "Backup e Restauro",
            "Ficheiros",
            "Configurações"
        };

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setOnClickListener(v -> Toast.makeText(MainActivity.this, "AM USB Tools", Toast.LENGTH_SHORT).show());
        }

        private float dp(float value) {
            return value * getResources().getDisplayMetrics().density;
        }

        private float sp(float value) {
            return value * getResources().getDisplayMetrics().scaledDensity;
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth();
            final float h = getHeight();
            final float density = getResources().getDisplayMetrics().density;
            final float contentTop = topInset;
            final float contentBottom = h - bottomInset;

            // Fundo azul escuro com gradiente suave, ocupando todo o ecrã.
            p.setShader(new LinearGradient(0, h * 0.10f, w, h * 0.92f,
                    Color.rgb(4, 16, 34), Color.rgb(24, 78, 142), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Cabeçalho: afastado da barra de estado para não haver sobreposição.
            final float side = dp(22);
            final float headerTop = contentTop + dp(16);

            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(sp(26));
            p.setColor(Color.WHITE);
            c.drawText("AM USB Tools", side, headerTop + sp(25), p);

            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(sp(14));
            p.setColor(Color.rgb(183, 202, 225));
            c.drawText("Ferramentas USB para Android", side, headerTop + sp(45), p);

            // Área central inspirada nos menus da AM Clientes: painel escuro, largo e compacto.
            final float panelLeft = dp(18);
            final float panelRight = w - dp(18);
            final float cardLeft = dp(28);
            final float cardRight = w - dp(28);
            final float cardHeight = dp(66);
            final float gap = dp(11);
            final float panelPaddingTop = dp(22);
            final float panelPaddingBottom = dp(22);
            final float panelHeight = panelPaddingTop + items.length * cardHeight + (items.length - 1) * gap + panelPaddingBottom;

            final float usableTop = contentTop + dp(78);
            final float usableBottom = contentBottom - dp(34);
            final float panelTop = usableTop + Math.max(0, (usableBottom - usableTop - panelHeight) * 0.54f);
            final float panelBottom = panelTop + panelHeight;

            // Painel exterior, como um grande balão escuro.
            r.set(panelLeft, panelTop, panelRight, panelBottom);
            p.setColor(Color.argb(112, 3, 18, 39));
            p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(dp(12), 0, dp(5), Color.argb(70, 0, 0, 0));
            c.drawRoundRect(r, dp(26), dp(26), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.2f));
            p.setColor(Color.argb(90, 95, 153, 224));
            c.drawRoundRect(r, dp(26), dp(26), p);
            p.setStyle(Paint.Style.FILL);

            for (int i = 0; i < items.length; i++) {
                final float top = panelTop + panelPaddingTop + i * (cardHeight + gap);
                r.set(cardLeft, top, cardRight, top + cardHeight);

                // Cartão individual: escuro, arredondado e com dimensão equilibrada.
                p.setColor(Color.argb(226, 5, 25, 49));
                p.setShadowLayer(dp(7), 0, dp(3), Color.argb(65, 0, 0, 0));
                c.drawRoundRect(r, dp(17), dp(17), p);
                p.clearShadowLayer();

                // Linha azul discreta à esquerda.
                p.setColor(Color.rgb(40, 125, 226));
                c.drawRoundRect(cardLeft, top + dp(12), cardLeft + dp(3), top + cardHeight - dp(12), dp(2), dp(2), p);

                final float iconX = cardLeft + dp(31);
                final float iconY = top + cardHeight / 2f;
                drawIcon(c, iconX, iconY, i);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(sp(18));
                p.setColor(Color.rgb(247, 249, 253));
                c.drawText(items[i], cardLeft + dp(61), iconY + sp(6), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(sp(27));
                p.setColor(Color.rgb(143, 184, 226));
                c.drawText("›", cardRight - dp(25), iconY + sp(8), p);
            }

            // Pequena assinatura, sem ocupar espaço útil.
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(sp(8));
            p.setColor(Color.rgb(105, 143, 184));
            c.drawText("AM USB Tools", side, contentBottom - dp(12), p);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(26, 78, 141));
            c.drawCircle(cx, cy, dp(15), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.8f));
            p.setColor(Color.rgb(207, 229, 250));

            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - dp(4), dp(3.5f), p);
                    c.drawLine(cx, cy, cx, cy + dp(8), p);
                    c.drawLine(cx, cy + dp(3), cx - dp(6), cy - dp(2), p);
                    c.drawLine(cx, cy + dp(3), cx + dp(6), cy - dp(2), p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, dp(8), p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - dp(4), dp(1.5f), p);
                    c.drawRect(cx - dp(1.2f), cy - dp(1), cx + dp(1.2f), cy + dp(6), p);
                    break;
                case 2:
                    c.drawRect(cx - dp(8), cy - dp(7), cx + dp(8), cy + dp(7), p);
                    c.drawLine(cx - dp(5), cy - dp(2), cx + dp(5), cy - dp(2), p);
                    c.drawLine(cx - dp(5), cy + dp(2), cx + dp(5), cy + dp(2), p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - dp(8), cy - dp(8), cx + dp(8), cy + dp(8)), 35, 285, false, p);
                    c.drawLine(cx + dp(5), cy - dp(7), cx + dp(9), cy - dp(7), p);
                    c.drawLine(cx + dp(8), cy - dp(7), cx + dp(8), cy - dp(3), p);
                    break;
                case 4:
                    r.set(cx - dp(9), cy - dp(7), cx + dp(9), cy + dp(8));
                    c.drawRoundRect(r, dp(2), dp(2), p);
                    c.drawLine(cx - dp(6), cy - dp(2), cx + dp(6), cy - dp(2), p);
                    break;
                default:
                    c.drawCircle(cx, cy, dp(4.5f), p);
                    c.drawCircle(cx, cy, dp(9), p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * 2 * i / 8.0;
                        float x1 = cx + (float) Math.cos(a) * dp(9);
                        float y1 = cy + (float) Math.sin(a) * dp(9);
                        float x2 = cx + (float) Math.cos(a) * dp(12);
                        float y2 = cy + (float) Math.sin(a) * dp(12);
                        c.drawLine(x1, y1, x2, y2, p);
                    }
                    break;
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
