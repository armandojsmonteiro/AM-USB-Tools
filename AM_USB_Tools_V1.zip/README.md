# AM USB Tools — V1

Primeira versão visual da aplicação.

Base visual: AM Respostas Automáticas V249.

Nesta versão a aplicação é apenas uma maquete visual: os botões ainda não executam operações USB.
