package pt.am.usbtools

import android.graphics.Color
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        applyGradient()
        val ids = intArrayOf(R.id.btnDetect, R.id.btnFormat, R.id.btnPartition, R.id.btnClean, R.id.btnInfo, R.id.btnTest, R.id.btnBackup, R.id.btnSettings, R.id.navHome, R.id.navUsb, R.id.navSettings)
        ids.forEach { id -> findViewById<View>(id).setOnClickListener { Toast.makeText(this, "Função será adicionada na próxima etapa.", Toast.LENGTH_SHORT).show() } }
    }

    private fun applyGradient() {
        val bg = findViewById<View>(R.id.gradientBackground)
        bg.background = object : android.graphics.drawable.Drawable() {
            private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            override fun onBoundsChange(b: android.graphics.Rect) {
                paint.shader = RadialGradient(b.exactCenterX(), b.exactCenterY(), maxOf(b.width(), b.height()) * .9f,
                    intArrayOf(Color.rgb(24,59,120), Color.rgb(15,40,88), Color.rgb(7,22,52), Color.rgb(2,7,24)),
                    floatArrayOf(0f,.42f,.78f,1f), Shader.TileMode.CLAMP)
            }
            override fun draw(c: android.graphics.Canvas) { c.drawRect(bounds, paint) }
            override fun setAlpha(a: Int) { paint.alpha=a; invalidateSelf() }
            override fun setColorFilter(f: android.graphics.ColorFilter?) { paint.colorFilter=f; invalidateSelf() }
            override fun getOpacity() = android.graphics.PixelFormat.OPAQUE
        }
    }
}
