package com.am.usbtools;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.am.usbtools.USB_PERMISSION";
    private static final int REQ_CREATE_BACKUP = 1201;
    private static final int REQ_RESTORE_BACKUP = 1202;
    private static final int REQ_FILE_TREE = 1203;

    private int topInset = 0;
    private int bottomInset = 0;
    private UsbManager usbManager;
    private PendingIntent usbPermissionIntent;
    private BroadcastReceiver usbPermissionReceiver;
    private JSONObject pendingBackup;
    private UsbMassStorage pendingMassStorage;
    private UsbDevice pendingImageDevice;
    private int pendingUsbAction = 0;

    private static final int USB_ACTION_NONE = 0;
    private static final int USB_ACTION_CLEAN = 1;
    private static final int USB_ACTION_FORMAT = 2;
    private static final int USB_ACTION_PARTITIONS = 3;
    private static final int USB_ACTION_BACKUP_CREATE = 4;
    private static final int USB_ACTION_BACKUP_RESTORE = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(6, 20, 38));
        window.setNavigationBarColor(Color.rgb(6, 20, 38));
        window.getDecorView().setSystemUiVisibility(0);
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);

        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        usbPermissionIntent = PendingIntent.getBroadcast(
                this,
                0,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),
                Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0
        );

        usbPermissionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                String label = device != null ? safeDeviceName(device) : "dispositivo USB";
                if (!granted || device == null) {
                    pendingUsbAction = USB_ACTION_NONE;
                    Toast.makeText(MainActivity.this,
                            "Autorização USB recusada: " + label, Toast.LENGTH_LONG).show();
                    return;
                }
                final int action = pendingUsbAction;
                pendingUsbAction = USB_ACTION_NONE;
                handleAuthorizedUsbAction(device, action);
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbPermissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbPermissionReceiver, filter);
        }

        HomeView home = new HomeView();
        home.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = 24;
                bottomInset = 48;
            }
            v.invalidate();
            return insets;
        });
        setContentView(home);
    }

    @Override
    protected void onDestroy() {
        if (usbPermissionReceiver != null) {
            try { unregisterReceiver(usbPermissionReceiver); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private AlertDialog.Builder lightDialogBuilder() {
        return new AlertDialog.Builder(this, R.style.AMLightDialogTheme);
    }

    private AlertDialog showLightDialog(AlertDialog.Builder builder) {
        AlertDialog dialog = builder.create();
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.WHITE);
            bg.setCornerRadius(dp(28));
            bg.setStroke(dp(1), Color.rgb(228, 232, 238));
            w.setBackgroundDrawable(bg);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.dimAmount = 0.55f;
            w.setAttributes(lp);
        }
        int blue = Color.rgb(55, 112, 230);
        if (dialog.getButton(AlertDialog.BUTTON_POSITIVE) != null) dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(blue);
        if (dialog.getButton(AlertDialog.BUTTON_NEGATIVE) != null) dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(blue);
        return dialog;
    }

    private TextView dialogText(String text, float sizeSp) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTextColor(Color.rgb(45, 48, 54));
        tv.setPadding(dp(2), dp(4), dp(2), dp(8));
        return tv;
    }

    private LinearLayout dialogColumn() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(2), dp(20), dp(2));
        return box;
    }

    private RadioButton dialogRadio(String label) {
        RadioButton rb = new RadioButton(this);
        rb.setText(label);
        rb.setTextSize(18);
        rb.setTextColor(Color.rgb(45, 48, 54));
        rb.setPadding(0, dp(5), 0, dp(5));
        return rb;
    }

    private List<UsbDevice> getMassStorageDevices() {
        List<UsbDevice> list = new ArrayList<>();
        for (UsbDevice device : usbManager.getDeviceList().values()) {
            boolean mass = false;
            for (int i = 0; i < device.getInterfaceCount(); i++) {
                UsbInterface itf = device.getInterface(i);
                if (itf.getInterfaceClass() == UsbConstants.USB_CLASS_MASS_STORAGE
                        && itf.getInterfaceSubclass() == 6
                        && itf.getInterfaceProtocol() == 80) {
                    mass = true;
                    break;
                }
            }
            if (mass) list.add(device);
        }
        return list;
    }

    private void chooseUsbDevice(int action) {
        final List<UsbDevice> list = getMassStorageDevices();
        if (list.isEmpty()) {
            lightDialogBuilder()
                    .setTitle("Nenhum USB de armazenamento")
                    .setMessage("Não foi detetada nenhuma pen ou unidade USB Mass Storage.\n\nLigue a pen através de OTG e tente novamente.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        String[] entries = new String[list.size()];
        for (int i = 0; i < list.size(); i++) entries[i] = buildUsbSummary(list.get(i));
        showLightDialog(lightDialogBuilder()
                .setTitle("Escolher dispositivo USB")
                .setItems(entries, (d, which) -> prepareUsbAction(list.get(which), action))
                .setNegativeButton("FECHAR", null));
    }

    private void prepareUsbAction(UsbDevice device, int action) {
        pendingUsbAction = action;
        if (usbManager.hasPermission(device)) {
            pendingUsbAction = USB_ACTION_NONE;
            handleAuthorizedUsbAction(device, action);
        } else {
            usbManager.requestPermission(device, usbPermissionIntent);
        }
    }

    private void handleAuthorizedUsbAction(UsbDevice device, int action) {
        switch (action) {
            case USB_ACTION_CLEAN:
                showCleanOptions(device);
                break;
            case USB_ACTION_FORMAT:
                showFormatOptions(device);
                break;
            case USB_ACTION_PARTITIONS:
                showPartitionAssistant(device);
                break;
            case USB_ACTION_BACKUP_CREATE:
                pendingImageDevice = device;
                createUsbImage();
                break;
            case USB_ACTION_BACKUP_RESTORE:
                pendingImageDevice = device;
                restoreUsbImage();
                break;
            case 13:
                runDefragAnalysis(device);
                break;
            default:
                break;
        }
    }

    private void showCleanOptions(UsbDevice device) {
        final String title = safeDeviceName(device) + "\n" + hex(device.getVendorId()) + ":" + hex(device.getProductId());
        LinearLayout content = dialogColumn();
        content.addView(dialogText("Dispositivo selecionado:\n" + title + "\n\nA limpeza é destrutiva. Escolhe o tipo:", 18));
        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.VERTICAL);
        RadioButton quick = dialogRadio("Limpeza rápida — apagar MBR e estruturas iniciais");
        RadioButton full = dialogRadio("Limpeza completa — escrever zeros em todo o USB");
        quick.setId(View.generateViewId());
        full.setId(View.generateViewId());
        group.addView(quick);
        group.addView(full);
        group.check(quick.getId());
        content.addView(group);
        showLightDialog(lightDialogBuilder()
                .setTitle("Limpar USB")
                .setView(content)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("CONTINUAR", (d, w) -> confirmClean(device, group.getCheckedRadioButtonId() == full.getId())));
    }

    private void confirmClean(UsbDevice device, boolean full) {
        String text = full
                ? "A limpeza completa vai escrever zeros em todo o dispositivo. Isto pode demorar bastante.\n\nContinuar?"
                : "A limpeza rápida vai remover a tabela de partições e as estruturas iniciais do USB.\n\nContinuar?";
        showLightDialog(lightDialogBuilder()
                .setTitle("ATENÇÃO")
                .setMessage(text)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("LIMPAR", (d, w) -> runClean(device, full)));
    }

    private void runClean(UsbDevice device, boolean full) {
        final AlertDialog progress = lightDialogBuilder()
                .setTitle(full ? "Limpeza completa" : "Limpeza rápida")
                .setMessage("A preparar…")
                .setCancelable(false)
                .create();
        progress.setButton(AlertDialog.BUTTON_NEGATIVE, "Fechar", (d, w) -> { });
        progress.show();
        progress.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(false);

        new Thread(() -> {
            try (UsbMassStorage storage = UsbMassStorage.open(this, usbManager, device)) {
                long total = storage.getSectorCount();
                if (full) {
                    byte[] zeros = new byte[64 * 1024];
                    long done = 0;
                    while (done < total) {
                        int sectors = (int)Math.min(128, total - done);
                        storage.write10(done, zeros, sectors * UsbMassStorage.SECTOR_SIZE);
                        done += sectors;
                        final int pct = (int)Math.min(100, (done * 100) / total);
                        runOnUiThread(() -> progress.setMessage("A limpar: " + pct + "%\n\nNão desligues o USB."));
                    }
                } else {
                    long first = Math.min(total, 2048);
                    byte[] zeros = new byte[64 * 1024];
                    long done = 0;
                    while (done < first) {
                        int sectors = (int)Math.min(128, first - done);
                        storage.write10(done, zeros, sectors * UsbMassStorage.SECTOR_SIZE);
                        done += sectors;
                    }
                    long tail = Math.min(total, 2048);
                    if (tail > 0) {
                        long startTail = Math.max(0, total - tail);
                        done = 0;
                        while (done < tail) {
                            int sectors = (int)Math.min(128, tail - done);
                            storage.write10(startTail + done, zeros, sectors * UsbMassStorage.SECTOR_SIZE);
                            done += sectors;
                        }
                    }
                }
                runOnUiThread(() -> {
                    progress.dismiss();
                    lightDialogBuilder()
                            .setTitle("Limpeza concluída")
                            .setMessage(full
                                    ? "O dispositivo foi sobrescrito com zeros. Pode agora criar uma nova partição e formatar o USB."
                                    : "A estrutura inicial do dispositivo foi removida. Pode agora criar uma nova partição e formatar o USB.")
                            .setPositiveButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.dismiss();
                    lightDialogBuilder()
                            .setTitle("Erro na limpeza")
                            .setMessage(e.getMessage() == null ? "Falha ao aceder ao dispositivo USB." : e.getMessage())
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        }, "AM-USB-Clean").start();
    }

    private void showFormatOptions(UsbDevice device) {
        final EditText label = new EditText(this);
        label.setHint("Etiqueta (opcional)");
        label.setSingleLine(true);
        label.setText("AM_USB");
        label.setTextColor(Color.rgb(45, 48, 54));
        label.setHintTextColor(Color.rgb(135, 140, 148));
        label.setTextSize(17);

        LinearLayout content = dialogColumn();
        content.addView(dialogText("Dispositivo:\n" + safeDeviceName(device) + "\n\nSistema de ficheiros:", 18));
        RadioGroup formats = new RadioGroup(this);
        formats.setOrientation(RadioGroup.VERTICAL);
        RadioButton fat32 = dialogRadio("FAT32");
        RadioButton exfat = dialogRadio("exFAT");
        fat32.setId(View.generateViewId());
        exfat.setId(View.generateViewId());
        formats.addView(fat32);
        formats.addView(exfat);
        formats.check(exfat.getId());
        content.addView(formats);

        content.addView(dialogText("Tabela de partição:", 18));
        RadioGroup partitions = new RadioGroup(this);
        partitions.setOrientation(RadioGroup.VERTICAL);
        RadioButton mbr = dialogRadio("MBR — suportado");
        RadioButton gpt = dialogRadio("GPT — em preparação");
        gpt.setEnabled(false);
        gpt.setTextColor(Color.rgb(155, 160, 168));
        mbr.setId(View.generateViewId());
        gpt.setId(View.generateViewId());
        partitions.addView(mbr);
        partitions.addView(gpt);
        partitions.check(mbr.getId());
        content.addView(partitions);

        content.addView(dialogText("Etiqueta do volume:", 16));
        content.addView(label, new LinearLayout.LayoutParams(-1, dp(52)));

        showLightDialog(lightDialogBuilder()
                .setTitle("Formatar USB")
                .setView(content)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("CONTINUAR", (d, w) -> {
                    String selected = formats.getCheckedRadioButtonId() == exfat.getId() ? "exFAT" : "FAT32";
                    confirmFormat(device, label.getText().toString().trim(), selected);
                }));
    }

    private void confirmFormat(UsbDevice device, String label, String format) {
        String cleanLabel = label.isEmpty() ? "AM_USB" : label;
        showLightDialog(lightDialogBuilder()
                .setTitle("ATENÇÃO — FORMATAR USB")
                .setMessage("Tudo o que estiver no dispositivo será perdido.\n\n" +
                        safeDeviceName(device) + "\n" +
                        "Formato: " + format + "\n" +
                        "Tabela de partição: MBR\n" +
                        "Etiqueta: " + cleanLabel + "\n\nContinuar?")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("FORMATAR", (d, w) -> runFormat(device, cleanLabel, format)));
    }

    private void runFormat(UsbDevice device, String label, String format) {
        final AlertDialog progress = lightDialogBuilder()
                .setTitle("Formatar " + format)
                .setMessage("A preparar o dispositivo…")
                .setCancelable(false)
                .create();
        progress.show();

        new Thread(() -> {
            try (UsbMassStorage storage = UsbMassStorage.open(this, usbManager, device)) {
                runOnUiThread(() -> progress.setMessage("A criar a estrutura " + format + "…\n\nNão desligues o USB."));
                if ("exFAT".equals(format)) {
                    ExFatFormatter.Result result = ExFatFormatter.format(storage, label);
                    runOnUiThread(() -> {
                        progress.dismiss();
                        lightDialogBuilder()
                                .setTitle("Formatação concluída")
                                .setMessage("USB formatado em exFAT.\n\n" +
                                        "Capacidade: " + String.format(Locale.US, "%.1f GB", result.capacityBytes / 1_000_000_000.0) + "\n" +
                                        "Cluster: " + result.bytesPerCluster + " bytes")
                                .setPositiveButton("OK", null).show();
                    });
                } else {
                    Fat32Formatter.Result result = Fat32Formatter.format(storage, label);
                    runOnUiThread(() -> {
                        progress.dismiss();
                        lightDialogBuilder()
                                .setTitle("Formatação concluída")
                                .setMessage("USB formatado em FAT32.\n\n" +
                                        "Capacidade: " + String.format(Locale.US, "%.1f GB", result.capacityBytes / 1_000_000_000.0) + "\n" +
                                        "Clusters: " + result.clusterCount + "\n" +
                                        "Tamanho do cluster: " + result.bytesPerCluster + " bytes")
                                .setPositiveButton("OK", null).show();
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.dismiss();
                    lightDialogBuilder()
                            .setTitle("Falha na formatação")
                            .setMessage(e.getMessage() == null ? "Não foi possível formatar o USB." : e.getMessage())
                            .setPositiveButton("OK", null).show();
                });
            }
        }, "AM-USB-Format").start();
    }

    private void showPartitionAssistant(UsbDevice device) {
        new Thread(() -> {
            try (UsbMassStorage storage = UsbMassStorage.open(this, usbManager, device)) {
                byte[] sector = storage.read10(0, 1);
                StringBuilder sb = new StringBuilder();
                sb.append("Dispositivo: ").append(safeDeviceName(device)).append("\n");
                sb.append("Capacidade: ").append(String.format(Locale.US, "%.1f GB", storage.getSectorCount() * UsbMassStorage.SECTOR_SIZE / 1_000_000_000.0)).append("\n\n");
                if ((sector[510] & 0xFF) != 0x55 || (sector[511] & 0xFF) != 0xAA) {
                    sb.append("Tabela de partições: não reconhecida (MBR inválido ou vazio).\n\n");
                } else {
                    sb.append("Tabela de partições: MBR\n\n");
                    for (int i = 0; i < 4; i++) {
                        int o = 446 + i * 16;
                        int type = sector[o + 4] & 0xFF;
                        long start = le32(sector, o + 8);
                        long count = le32(sector, o + 12);
                        if (type == 0 || count == 0) continue;
                        sb.append("Partição ").append(i + 1)
                                .append(": tipo 0x").append(String.format(Locale.US, "%02X", type))
                                .append(" • início ").append(start)
                                .append(" • setores ").append(count)
                                .append(" • ").append(String.format(Locale.US, "%.1f GB", count * 512 / 1_000_000_000.0))
                                .append("\n");
                    }
                }
                sb.append("\nNesta versão o assistente já lê a estrutura MBR. A criação/eliminação de partições fica preparada para a próxima etapa.");
                final String msg = sb.toString();
                runOnUiThread(() -> lightDialogBuilder()
                        .setTitle("Assistente de Partições")
                        .setMessage(msg)
                        .setPositiveButton("OK", null)
                        .show());
            } catch (Exception e) {
                runOnUiThread(() -> lightDialogBuilder()
                        .setTitle("Assistente de Partições")
                        .setMessage("Não foi possível ler a tabela de partições.\n\n" + e.getMessage())
                        .setPositiveButton("OK", null)
                        .show());
            }
        }, "AM-USB-Partition").start();
    }

    private int le16(byte[] a, int off) { return (a[off] & 0xFF) | ((a[off + 1] & 0xFF) << 8); }

    private long le32(byte[] a, int off) {
        return (a[off] & 0xFFL) |
                ((a[off + 1] & 0xFFL) << 8) |
                ((a[off + 2] & 0xFFL) << 16) |
                ((a[off + 3] & 0xFFL) << 24);
    }

    private void showDeviceInformation() {
        StringBuilder sb = new StringBuilder();
        sb.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("Fabricante: ").append(Build.MANUFACTURER).append("\n");
        sb.append("Modelo: ").append(Build.MODEL).append("\n");
        sb.append("Marca: ").append(Build.BRAND).append("\n\n");
        Map<String, UsbDevice> devices = usbManager.getDeviceList();
        sb.append("USB ligados: ").append(devices.size()).append("\n");
        for (UsbDevice device : devices.values()) {
            sb.append("• ").append(safeDeviceName(device))
                    .append(" — VID ").append(hex(device.getVendorId()))
                    .append(" / PID ").append(hex(device.getProductId()))
                    .append("\n");
        }
        showLightDialog(lightDialogBuilder()
                .setTitle("Informação do dispositivo")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null));
    }

    private void showFormatInfo() {
        Map<String, UsbDevice> devices = usbManager.getDeviceList();
        String message;
        if (devices.isEmpty()) {
            message = "Não existe nenhum dispositivo USB detetado neste momento.\n\nLigue a pen ou disco USB e volte a entrar nesta opção.";
        } else {
            message = "Foram detetados " + devices.size() + " dispositivo(s) USB.\n\n" +
                    "A AM USB Tools já consegue identificar o equipamento, mas o Android não disponibiliza uma API pública genérica para formatar qualquer armazenamento USB diretamente pela aplicação.\n\n" +
                    "Vamos preparar esta área para usar o mecanismo de armazenamento permitido pelo sistema, sem correr o risco de apagar um disco errado.";
        }

        lightDialogBuilder()
                .setTitle("Formatar USB")
                .setMessage(message)
                .setPositiveButton("Escolher armazenamento", (dialog, which) -> openTreePicker())
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void showDefragInfo() {
        final List<UsbDevice> devices = getMassStorageDevices();
        if (devices.isEmpty()) {
            lightDialogBuilder()
                    .setTitle("Desfragmentador USB")
                    .setMessage("Ligue uma pen USB e volte a entrar nesta opção.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        String[] entries = new String[devices.size()];
        for (int i=0;i<devices.size();i++) entries[i] = buildUsbSummary(devices.get(i));
        lightDialogBuilder()
                .setTitle("Desfragmentador USB — escolher unidade")
                .setItems(entries, (d,w) -> prepareUsbAction(devices.get(w), 13))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void runDefragAnalysis(UsbDevice device) {
        new Thread(() -> {
            try (UsbMassStorage storage = UsbMassStorage.open(this, usbManager, device)) {
                byte[] boot = storage.read10(0, 1);
                int oem = boot[0] & 0xFF;
                if (oem != 0xEB && oem != 0xE9) throw new IllegalStateException("O primeiro setor não parece ser um volume FAT/FAT32.");
                int bytesPerSector = le16(boot, 11);
                int spc = boot[13] & 0xFF;
                int reserved = le16(boot, 14);
                int fats = boot[16] & 0xFF;
                long total = le32(boot, 32);
                if (total == 0) total = le32(boot, 19);
                long fatSectors = le32(boot, 36);
                long rootCluster = le32(boot, 44);
                if (bytesPerSector != 512 || spc == 0 || fats < 1 || fatSectors == 0 || rootCluster < 2) {
                    throw new IllegalStateException("O volume não é FAT32 compatível com a análise.");
                }
                long clusterCount = (total - reserved - fats*fatSectors) / spc;
                if (clusterCount < 1) throw new IllegalStateException("Estrutura FAT32 inválida.");
                byte[] fatHead = storage.read10(2048 + reserved, 8);
                int firstFatEntry = (fatHead[8] & 0xFF) | ((fatHead[9] & 0xFF)<<8) | ((fatHead[10] & 0xFF)<<16) | ((fatHead[11]&0x0F)<<24);
                final String msg = "FAT32 detetado.\n\n" +
                        "Clusters: " + clusterCount + "\n" +
                        "Tamanho do cluster: " + (spc*bytesPerSector) + " bytes\n" +
                        "FATs: " + fats + "\n" +
                        "Cluster raiz: " + rootCluster + "\n" +
                        "\nA AM USB Tools já consegue analisar a estrutura FAT32. A reorganização física dos ficheiros será adicionada sem arriscar perda de dados.";
                runOnUiThread(() -> lightDialogBuilder()
                        .setTitle("Análise FAT32")
                        .setMessage(msg)
                        .setPositiveButton("OK", null)
                        .show());
            } catch (Exception e) {
                runOnUiThread(() -> lightDialogBuilder()
                        .setTitle("Análise FAT32")
                        .setMessage(e.getMessage() == null ? "Não foi possível analisar o USB." : e.getMessage())
                        .setPositiveButton("OK", null)
                        .show());
            }
        }, "AM-USB-DefragAnalysis").start();
    }

    private void openBackupMenu() {
        final String[] actions = {"Criar imagem completa do USB", "Restaurar imagem para o USB"};
        lightDialogBuilder()
                .setTitle("Backup e Restauro")
                .setItems(actions, (dialog, which) ->
                        chooseUsbForBackup(which == 0 ? USB_ACTION_BACKUP_CREATE : USB_ACTION_BACKUP_RESTORE))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void chooseUsbForBackup(int action) {
        final List<UsbDevice> list = getMassStorageDevices();
        if (list.isEmpty()) {
            lightDialogBuilder()
                    .setTitle("Nenhum USB de armazenamento")
                    .setMessage("Ligue primeiro a pen/disco USB através de OTG.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        String[] entries = new String[list.size()];
        for (int i=0;i<list.size();i++) entries[i] = buildUsbSummary(list.get(i));
        lightDialogBuilder()
                .setTitle("Escolher USB")
                .setItems(entries, (d,w) -> prepareUsbAction(list.get(w), action))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void createUsbImage() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, "AM_USB_Tools_Backup.img");
        startActivityForResult(intent, REQ_CREATE_BACKUP);
    }

    private void restoreUsbImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        startActivityForResult(intent, REQ_RESTORE_BACKUP);
    }

    private JSONObject buildBackupJson() {
        JSONObject root = new JSONObject();
        try {
            root.put("app", "AM USB Tools");
            root.put("version", 30);
            root.put("createdAt", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(new Date()));
            root.put("android", Build.VERSION.RELEASE);
            root.put("manufacturer", Build.MANUFACTURER);
            root.put("model", Build.MODEL);

            JSONArray usbArray = new JSONArray();
            for (UsbDevice device : usbManager.getDeviceList().values()) {
                JSONObject item = new JSONObject();
                item.put("name", safeDeviceName(device));
                item.put("vendorId", device.getVendorId());
                item.put("productId", device.getProductId());
                item.put("class", device.getDeviceClass());
                item.put("subclass", device.getDeviceSubclass());
                item.put("protocol", device.getDeviceProtocol());
                item.put("interfaceCount", device.getInterfaceCount());
                usbArray.put(item);
            }
            root.put("usbDevices", usbArray);
        } catch (JSONException ignored) {
            // The values above are primitive and should not fail in practice.
        }
        return root;
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_FILE_TREE);
    }

    private void openTreePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.putExtra("android.content.extra.SHOW_ADVANCED", true);
        startActivityForResult(intent, REQ_FILE_TREE);
    }

    private void openSettings() {
        lightDialogBuilder()
                .setTitle("Configurações")
                .setMessage("As definições da AM USB Tools serão adicionadas nesta área.\n\nPor agora, pode abrir as definições Android da aplicação.")
                .setPositiveButton("Definições Android", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("Fechar", null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_CREATE_BACKUP) {
            if (pendingImageDevice == null) { Toast.makeText(this, "Nenhum USB selecionado.", Toast.LENGTH_LONG).show(); return; }
            final UsbDevice target = pendingImageDevice;
            runUsbImageCreate(target, uri);
        } else if (requestCode == REQ_RESTORE_BACKUP) {
            if (pendingImageDevice == null) { Toast.makeText(this, "Nenhum USB selecionado.", Toast.LENGTH_LONG).show(); return; }
            final UsbDevice target = pendingImageDevice;
            runUsbImageRestore(target, uri);
        }
    }

    private void runUsbImageCreate(UsbDevice device, Uri uri) {
        final AlertDialog progress = lightDialogBuilder()
                .setTitle("Criar imagem de backup")
                .setMessage("A preparar…")
                .setCancelable(false)
                .create();
        progress.show();
        new Thread(() -> {
            try (UsbMassStorage storage = UsbMassStorage.open(this, usbManager, device);
                 OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IOException("Não foi possível criar o ficheiro de destino.");
                long total = storage.getSectorCount();
                long done = 0;
                while (done < total) {
                    int blocks = (int)Math.min(128, total - done);
                    byte[] data = storage.read10(done, blocks);
                    out.write(data);
                    done += blocks;
                    final int pct = (int)Math.min(100, done * 100 / total);
                    runOnUiThread(() -> progress.setMessage("A criar imagem: " + pct + "%"));
                }
                out.flush();
                runOnUiThread(() -> { progress.dismiss(); Toast.makeText(this, "Imagem de backup criada.", Toast.LENGTH_LONG).show(); });
            } catch (Exception e) {
                runOnUiThread(() -> { progress.dismiss(); lightDialogBuilder().setTitle("Erro no backup").setMessage(e.getMessage()).setPositiveButton("OK", null).show(); });
            } finally { pendingImageDevice = null; }
        }, "AM-USB-BackupCreate").start();
    }

    private void runUsbImageRestore(UsbDevice device, Uri uri) {
        final AlertDialog progress = lightDialogBuilder()
                .setTitle("Restaurar imagem USB")
                .setMessage("A preparar…")
                .setCancelable(false)
                .create();
        progress.show();
        new Thread(() -> {
            try (UsbMassStorage storage = UsbMassStorage.open(this, usbManager, device);
                 InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("Não foi possível abrir a imagem de backup.");
                long totalBytes = storage.getCapacityBytes();
                byte[] buffer = new byte[64 * 1024];
                long sector = 0;
                int n;
                while ((n = readFullyUpTo(in, buffer)) > 0) {
                    if (n % UsbMassStorage.SECTOR_SIZE != 0) throw new IOException("A imagem não está alinhada a setores de 512 bytes.");
                    int blocks = n / UsbMassStorage.SECTOR_SIZE;
                    if ((sector + blocks) * (long)UsbMassStorage.SECTOR_SIZE > totalBytes) throw new IOException("A imagem é maior do que o dispositivo USB.");
                    storage.write10(sector, buffer, n);
                    sector += blocks;
                    final int pct = totalBytes == 0 ? 0 : (int)Math.min(100, sector * 100L * UsbMassStorage.SECTOR_SIZE / totalBytes);
                    runOnUiThread(() -> progress.setMessage("A restaurar: " + pct + "%\n\nNão desligues o USB."));
                }
                runOnUiThread(() -> { progress.dismiss(); lightDialogBuilder().setTitle("Restauro concluído").setMessage("A imagem foi escrita no dispositivo USB.").setPositiveButton("OK", null).show(); });
            } catch (Exception e) {
                runOnUiThread(() -> { progress.dismiss(); lightDialogBuilder().setTitle("Erro no restauro").setMessage(e.getMessage()).setPositiveButton("OK", null).show(); });
            } finally { pendingImageDevice = null; }
        }, "AM-USB-BackupRestore").start();
    }

    private int readFullyUpTo(InputStream in, byte[] buffer) throws IOException {
        int off = 0;
        while (off < buffer.length) {
            int n = in.read(buffer, off, buffer.length - off);
            if (n < 0) break;
            if (n == 0) continue;
            off += n;
        }
        return off;
    }

    private String safeDeviceName(UsbDevice device) {
        String product = Build.VERSION.SDK_INT >= 21 ? device.getProductName() : null;
        if (product != null && !product.trim().isEmpty()) return product;
        return "USB VID " + hex(device.getVendorId()) + " / PID " + hex(device.getProductId());
    }

    private String buildUsbSummary(UsbDevice device) {
        return safeDeviceName(device) + "\nVID " + hex(device.getVendorId()) +
                " • PID " + hex(device.getProductId()) +
                " • Interfaces " + device.getInterfaceCount();
    }

    private String buildUsbDetail(UsbDevice device, boolean authorized) {
        StringBuilder sb = new StringBuilder();
        sb.append("Fabricante/VID: ").append(hex(device.getVendorId())).append("\n");
        sb.append("Produto/PID: ").append(hex(device.getProductId())).append("\n");
        sb.append("Classe: ").append(device.getDeviceClass()).append("\n");
        sb.append("Subclasse: ").append(device.getDeviceSubclass()).append("\n");
        sb.append("Protocolo: ").append(device.getDeviceProtocol()).append("\n");
        sb.append("Interfaces: ").append(device.getInterfaceCount()).append("\n");
        sb.append("Autorização: ").append(authorized ? "concedida" : "não concedida").append("\n\n");
        for (int i = 0; i < device.getInterfaceCount(); i++) {
            UsbInterface usbInterface = device.getInterface(i);
            sb.append("Interface ").append(i + 1)
                    .append(" — classe ").append(usbInterface.getInterfaceClass())
                    .append(", subclasse ").append(usbInterface.getInterfaceSubclass())
                    .append(", protocolo ").append(usbInterface.getInterfaceProtocol())
                    .append("\n");
        }
        return sb.toString();
    }

    private String hex(int value) {
        return String.format(Locale.US, "0x%04X", value & 0xFFFF);
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Path path = new Path();
        private final Bitmap appLogo = BitmapFactory.decodeResource(getResources(), R.drawable.am_usb_logo);
        private final Bitmap heroUsb = BitmapFactory.decodeResource(getResources(), R.drawable.hero_usb);
        private final String[] titles = {
                "Limpar USB", "Formatar USB", "Desfragmentador USB",
                "Assistente de Partições", "Backup e Restauro", "Informação do Dispositivo"
        };
        private final String[] subtitles = {
                "Apagar dados e estruturas", "FAT32 • exFAT • formatação direta", "Analisar estrutura FAT32",
                "Ver e gerir partições", "Criar e restaurar cópias", "Detalhes técnicos do USB"
        };
        private final int[] iconColors = {
                Color.rgb(30, 111, 225), Color.rgb(35, 117, 220), Color.rgb(22, 153, 230),
                Color.rgb(117, 65, 210), Color.rgb(16, 163, 157), Color.rgb(66, 126, 205)
        };
        private float[] cardTops = new float[6];
        private float cardHeight;

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setFocusable(true);
        }

        private float u(float v) { return v * (getWidth() / 686f); }
        private float text(float v) { return u(v); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth(), h = getHeight();
            final float contentBottom = h - bottomInset;

            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(4, 18, 35), Color.rgb(28, 86, 168), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setShader(new LinearGradient(0, h * .48f, w, h,
                    Color.argb(0, 8, 36, 70), Color.argb(95, 25, 120, 230), Shader.TileMode.CLAMP));
            c.drawRect(0, h * .42f, w, h, p);
            p.setShader(null);

            final float side = u(42);
            final float headerY = topInset + u(18);
            final float logoSize = u(62);

            if (appLogo != null) {
                r.set(side, headerY, side + logoSize, headerY + logoSize);
                p.setAlpha(255);
                c.drawBitmap(appLogo, null, r, p);
            }
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(text(36));
            p.setColor(Color.rgb(21, 155, 255));
            final float titleX = side + logoSize + u(16);
            c.drawText("AM", titleX, headerY + u(38), p);
            final float amWidth = p.measureText("AM");
            p.setColor(Color.WHITE);
            c.drawText(" USB Tools", titleX + amWidth, headerY + u(38), p);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(text(18));
            p.setColor(Color.rgb(164, 192, 225));
            c.drawText("Ferramentas USB para Android", titleX, headerY + u(60), p);
            p.setTextSize(text(30));
            p.setColor(Color.WHITE);
            c.drawText("⋮", w - u(38), headerY + u(39), p);

            final float heroTop = headerY + u(78);
            final float heroH = u(270);
            if (heroUsb != null) {
                r.set(u(34), heroTop, w - u(34), heroTop + heroH);
                p.setAlpha(255);
                c.drawBitmap(heroUsb, null, r, p);
            }

            final float panelLeft = u(24), panelRight = w - u(24);
            final float panelTop = heroTop + heroH - u(2);
            final float panelBottom = Math.min(contentBottom - u(70), panelTop + u(785));
            r.set(panelLeft, panelTop, panelRight, panelBottom);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(185, 3, 24, 48));
            p.setShadowLayer(u(18), 0, u(8), Color.argb(80, 0,0,0));
            c.drawRoundRect(r, u(28), u(28), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(1.3f));
            p.setColor(Color.argb(170, 57, 122, 220));
            c.drawRoundRect(r, u(28), u(28), p);
            p.setStyle(Paint.Style.FILL);

            final float innerLeft = panelLeft + u(18), innerRight = panelRight - u(18);
            final float innerTop = panelTop + u(20);
            final float gap = u(10);
            final float available = panelBottom - innerTop - u(18);
            cardHeight = Math.min(u(104), (available - gap * 5) / 6f);

            for (int i = 0; i < 6; i++) {
                float top = innerTop + i * (cardHeight + gap);
                cardTops[i] = top;
                r.set(innerLeft, top, innerRight, top + cardHeight);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(205, 4, 25, 50));
                p.setShadowLayer(u(8), 0, u(4), Color.argb(75,0,0,0));
                c.drawRoundRect(r, u(21), u(21), p);
                p.clearShadowLayer();
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(u(1));
                p.setColor(Color.argb(165, 42, 92, 158));
                c.drawRoundRect(r, u(21), u(21), p);
                p.setStyle(Paint.Style.FILL);

                final float iconX = innerLeft + u(58);
                final float iconY = top + cardHeight / 2f;
                drawIcon(c, iconX, iconY, i, iconColors[i]);

                final float copyX = innerLeft + u(120);
                final float arrowX = innerRight - u(28);
                final float maxTextW = arrowX - copyX - u(20);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(text(i == 5 ? 30 : 33));
                p.setColor(Color.WHITE);
                String title = titles[i];
                while (p.measureText(title) > maxTextW && p.getTextSize() > text(16)) p.setTextSize(p.getTextSize() - text(1));
                c.drawText(title, copyX, iconY - u(4), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(text(22.5f));
                p.setColor(Color.rgb(156, 187, 224));
                String sub = subtitles[i];
                while (p.measureText(sub) > maxTextW && p.getTextSize() > text(12)) p.setTextSize(p.getTextSize() - text(.5f));
                c.drawText(sub, copyX, iconY + u(23), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(text(42));
                p.setColor(Color.rgb(55, 112, 210));
                c.drawText("›", arrowX, iconY + u(13), p);
            }

            drawWave(c, w, contentBottom - u(93));
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(text(18));
            p.setColor(Color.rgb(170, 198, 230));
            String footer = "Simples. Seguro. Sempre consigo.";
            float tw = p.measureText(footer);
            c.drawText(footer, (w - tw) / 2f, contentBottom - u(38), p);

            p.setTextSize(text(9));
            p.setColor(Color.rgb(121, 161, 210));
            p.setLetterSpacing(.32f);
            String small = "A  L I G A Ç Ã O  E N T R E  S I  E  O  S E U  M U N D O";
            tw = p.measureText(small);
            c.drawText(small, (w - tw) / 2f, contentBottom - u(13), p);
            p.setLetterSpacing(0f);
            p.setAlpha(255);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setShadowLayer(u(6), 0, u(2), Color.argb(90, 0, 0, 0));
            c.drawCircle(cx, cy, u(28), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(2.4f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(235, 247, 255));
            switch (type) {
                case 0: // limpar
                    c.drawRoundRect(new RectF(cx-u(12), cy-u(7), cx+u(7), cy+u(9)), u(3), u(3), p);
                    c.drawLine(cx-u(4), cy-u(10), cx+u(13), cy+u(7), p);
                    c.drawLine(cx-u(9), cy+u(10), cx+u(9), cy-u(10), p);
                    break;
                case 1: // formatar
                    c.drawRoundRect(new RectF(cx-u(10), cy-u(11), cx+u(10), cy+u(11)), u(2), u(2), p);
                    c.drawLine(cx-u(6), cy-u(3), cx+u(6), cy-u(3), p);
                    c.drawLine(cx-u(6), cy+u(3), cx+u(6), cy+u(3), p);
                    break;
                case 2: // desfragmentar
                    c.drawArc(new RectF(cx-u(10), cy-u(10), cx+u(10), cy+u(10)), 25, 285, false, p);
                    c.drawLine(cx+u(7), cy-u(9), cx+u(12), cy-u(8), p);
                    c.drawLine(cx+u(12), cy-u(8), cx+u(9), cy-u(3), p);
                    c.drawLine(cx-u(8), cy+u(14), cx-u(8), cy+u(7), p);
                    c.drawLine(cx, cy+u(14), cx, cy+u(2), p);
                    c.drawLine(cx+u(8), cy+u(14), cx+u(8), cy-u(2), p);
                    break;
                case 3: // partições
                    c.drawRect(cx-u(11), cy-u(11), cx-u(1), cy-u(1), p);
                    c.drawRect(cx+u(1), cy-u(11), cx+u(11), cy-u(1), p);
                    c.drawRect(cx-u(11), cy+u(1), cx-u(1), cy+u(11), p);
                    c.drawRect(cx+u(1), cy+u(1), cx+u(11), cy+u(11), p);
                    break;
                case 4: // backup
                    c.drawArc(new RectF(cx-u(10), cy-u(10), cx+u(10), cy+u(10)), 35, 290, false, p);
                    c.drawLine(cx+u(6), cy-u(8), cx+u(11), cy-u(8), p);
                    c.drawLine(cx+u(11), cy-u(8), cx+u(8), cy-u(3), p);
                    break;
                default: // informação
                    c.drawCircle(cx, cy, u(10), p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy-u(5), u(1.8f), p);
                    c.drawRoundRect(new RectF(cx-u(1.7f), cy-u(1), cx+u(1.7f), cy+u(7)), u(1), u(1), p);
                    break;
            }
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawWave(Canvas c, float w, float y) {
            path.reset();
            path.moveTo(u(52), y + u(12));
            path.cubicTo(w * .25f, y - u(10), w * .34f, y + u(23), w * .52f, y + u(4));
            path.cubicTo(w * .69f, y - u(14), w * .77f, y + u(18), w - u(52), y - u(2));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(2));
            p.setColor(Color.argb(150, 52, 143, 238));
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float x = e.getX(), y = e.getY();
            final float left = u(34), right = getWidth() - u(34);
            for (int i = 0; i < 6; i++) {
                if (y >= cardTops[i] && y <= cardTops[i] + cardHeight && x >= left && x <= right) {
                    switch (i) {
                        case 0: chooseUsbDevice(USB_ACTION_CLEAN); break;
                        case 1: chooseUsbDevice(USB_ACTION_FORMAT); break;
                        case 2: showDefragInfo(); break;
                        case 3: chooseUsbDevice(USB_ACTION_PARTITIONS); break;
                        case 4: openBackupMenu(); break;
                        case 5: showDeviceInformation(); break;
                        default: break;
                    }
                    return true;
                }
            }
            return true;
        }
    }
}
