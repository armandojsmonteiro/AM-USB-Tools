package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(7, 20, 38));
        window.setNavigationBarColor(Color.rgb(7, 20, 38));
        setContentView(new HomeView());
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final String[] items = {
            "Dispositivo USB",
            "Informação do dispositivo",
            "Formatar USB",
            "Backup e Restauro",
            "Ficheiros",
            "Configurações"
        };

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setOnClickListener(v -> Toast.makeText(MainActivity.this, "AM USB Tools V8", Toast.LENGTH_SHORT).show());
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth();
            float h = getHeight();

            // Fundo com gradiente diagonal, mais profundo no topo e luminoso no centro.
            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(5, 15, 31), Color.rgb(18, 65, 122), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Cabeçalho compacto e alinhado.
            float x = 24;
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(25);
            p.setColor(Color.WHITE);
            c.drawText("AM USB Tools", x, 46, p);

            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(12.5f);
            p.setColor(Color.rgb(166, 191, 220));
            c.drawText("Ferramentas USB para Android", x, 66, p);

            // Pequeno indicador de versão, sem roubar espaço ao menu.
            p.setTextSize(10);
            p.setColor(Color.rgb(112, 151, 196));
            c.drawText("V8", w - 42, 45, p);

            // Menu em cartões compactos, com hierarquia visual e ícones simples.
            float left = 18;
            float right = w - 18;
            float top = 92;
            float bh = 57;
            float gap = 9;

            for (int i = 0; i < items.length; i++) {
                r.set(left, top, right, top + bh);

                // Sombra suave para destacar os cartões do fundo.
                p.setShadowLayer(8, 0, 3, Color.argb(65, 0, 0, 0));
                p.setColor(Color.argb(205, 13, 34, 61));
                c.drawRoundRect(r, 15, 15, p);
                p.clearShadowLayer();

                // Linha de destaque lateral.
                p.setColor(Color.rgb(48, 116, 207));
                c.drawRoundRect(left, top + 15, left + 4, top + bh - 15, 2, 2, p);

                drawIcon(c, left + 29, top + bh / 2, i);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(14.5f);
                p.setColor(Color.rgb(239, 245, 252));
                c.drawText(items[i], left + 52, top + 34, p);

                // Seta discreta à direita.
                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(20);
                p.setColor(Color.rgb(116, 151, 190));
                c.drawText("›", right - 27, top + 37, p);

                top += bh + gap;
            }

            // Rodapé discreto.
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(10);
            p.setColor(Color.rgb(101, 137, 178));
            c.drawText("AM USB Tools V8", 24, h - 18, p);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(31, 82, 140));
            c.drawCircle(cx, cy, 15, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2);
            p.setColor(Color.rgb(183, 215, 247));

            switch (type) {
                case 0: // USB
                    c.drawCircle(cx, cy - 3, 4, p);
                    c.drawLine(cx, cy + 1, cx, cy + 8, p);
                    c.drawLine(cx, cy + 3, cx - 6, cy - 2, p);
                    c.drawLine(cx, cy + 3, cx + 6, cy - 2, p);
                    break;
                case 1: // Informação
                    c.drawCircle(cx, cy, 8, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - 4, 1.5f, p);
                    c.drawRect(cx - 1.2f, cy - 1, cx + 1.2f, cy + 7, p);
                    break;
                case 2: // Formatar
                    c.drawRect(cx - 8, cy - 7, cx + 8, cy + 7, p);
                    c.drawLine(cx - 5, cy - 3, cx + 5, cy - 3, p);
                    c.drawLine(cx - 5, cy + 2, cx + 5, cy + 2, p);
                    break;
                case 3: // Backup
                    c.drawArc(new RectF(cx - 8, cy - 8, cx + 8, cy + 8), 35, 280, false, p);
                    c.drawLine(cx + 5, cy - 7, cx + 9, cy - 7, p);
                    c.drawLine(cx + 8, cy - 7, cx + 8, cy - 3, p);
                    break;
                case 4: // Ficheiros
                    r.set(cx - 9, cy - 7, cx + 9, cy + 8);
                    c.drawRoundRect(r, 2, 2, p);
                    c.drawLine(cx - 6, cy - 3, cx + 6, cy - 3, p);
                    break;
                default: // Configurações
                    c.drawCircle(cx, cy, 4, p);
                    c.drawCircle(cx, cy, 9, p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * 2 * i / 8.0;
                        float x1 = cx + (float)Math.cos(a) * 9;
                        float y1 = cy + (float)Math.sin(a) * 9;
                        float x2 = cx + (float)Math.cos(a) * 12;
                        float y2 = cy + (float)Math.sin(a) * 12;
                        c.drawLine(x1, y1, x2, y2, p);
                    }
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
