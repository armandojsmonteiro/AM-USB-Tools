package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int topInset = 0;
    private int bottomInset = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(5, 17, 34));
        window.setNavigationBarColor(Color.rgb(5, 24, 48));
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);

        HomeView home = new HomeView();
        home.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = 24;
                bottomInset = 48;
            }
            v.invalidate();
            return insets;
        });
        setContentView(home);
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final String[] titles = {
                "Dispositivo USB", "Informação do dispositivo", "Formatar USB",
                "Backup e Restauro", "Ficheiros", "Configurações"
        };
        private final String[] subtitles = {
                "Detetar e gerir dispositivos", "Detalhes e especificações", "Formatar com segurança",
                "Copiar e restaurar dados", "Explorar e gerir ficheiros", "Personalizar a aplicação"
        };

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
        private float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth(), h = getHeight();
            final float contentTop = topInset;
            final float contentBottom = h - bottomInset;

            // Fundo integral: azul muito escuro no topo, azul mais vivo na zona inferior.
            p.setShader(new LinearGradient(0, 0, w * .95f, h,
                    new int[]{Color.rgb(3, 14, 29), Color.rgb(7, 34, 68), Color.rgb(28, 91, 164)},
                    new float[]{0f, .58f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);

            final float side = dp(22);
            final float headerTop = contentTop + dp(24);

            // Cabeçalho limpo, igual ao conceito aprovado.
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(sp(29));
            p.setColor(Color.WHITE);
            c.drawText("AM USB Tools", side, headerTop + sp(29), p);

            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(sp(16));
            p.setColor(Color.rgb(179, 201, 229));
            c.drawText("Ferramentas USB para Android", side, headerTop + sp(52), p);

            // Pequeno símbolo AM + USB no cabeçalho.
            drawMiniLogo(c, w - dp(49), headerTop + dp(29));

            // Painel central em formato de balão, ocupando a zona útil sem deixar o menu colado ao topo.
            final float panelLeft = dp(16);
            final float panelRight = w - dp(16);
            final float cardLeft = dp(28);
            final float cardRight = w - dp(28);
            final float cardHeight = dp(92);
            final float gap = dp(12);
            final float panelPadTop = dp(22);
            final float panelPadBottom = dp(22);
            final float panelHeight = panelPadTop + 6 * cardHeight + 5 * gap + panelPadBottom;
            final float availableTop = contentTop + dp(92);
            final float availableBottom = contentBottom - dp(52);
            final float panelTop = availableTop + Math.max(0, (availableBottom - availableTop - panelHeight) * .46f);

            r.set(panelLeft, panelTop, panelRight, panelTop + panelHeight);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(105, 2, 17, 37));
            p.setShadowLayer(dp(18), 0, dp(8), Color.argb(85, 0, 0, 0));
            c.drawRoundRect(r, dp(30), dp(30), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.4f));
            p.setColor(Color.argb(105, 91, 157, 230));
            c.drawRoundRect(r, dp(30), dp(30), p);
            p.setStyle(Paint.Style.FILL);

            for (int i = 0; i < 6; i++) {
                float top = panelTop + panelPadTop + i * (cardHeight + gap);
                r.set(cardLeft, top, cardRight, top + cardHeight);

                // Cartão escuro, alto o suficiente para título + descrição, mas sem exagerar.
                p.setColor(Color.argb(238, 3, 24, 49));
                p.setShadowLayer(dp(9), 0, dp(4), Color.argb(75, 0, 0, 0));
                c.drawRoundRect(r, dp(22), dp(22), p);
                p.clearShadowLayer();

                // Linha azul de destaque.
                p.setColor(Color.rgb(38, 126, 235));
                c.drawRoundRect(cardLeft, top + dp(16), cardLeft + dp(4), top + cardHeight - dp(16), dp(2), dp(2), p);

                drawIcon(c, cardLeft + dp(42), top + cardHeight / 2f, i);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(sp(19));
                p.setColor(Color.WHITE);
                c.drawText(titles[i], cardLeft + dp(78), top + dp(39), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(sp(13));
                p.setColor(Color.rgb(139, 174, 211));
                c.drawText(subtitles[i], cardLeft + dp(78), top + dp(63), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(sp(32));
                p.setColor(Color.rgb(137, 185, 236));
                c.drawText("›", cardRight - dp(29), top + dp(58), p);
            }

            // Elemento decorativo inferior, inspirado no mockup aprovado.
            float waveY = contentBottom - dp(76);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(Color.argb(130, 59, 151, 247));
            Path wave = new Path();
            wave.moveTo(dp(50), waveY + dp(7));
            wave.cubicTo(w * .25f, waveY - dp(13), w * .36f, waveY + dp(25), w * .52f, waveY + dp(4));
            wave.cubicTo(w * .67f, waveY - dp(18), w * .80f, waveY + dp(17), w - dp(50), waveY - dp(1));
            c.drawPath(wave, p);
            p.setStyle(Paint.Style.FILL);

            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(sp(9));
            p.setColor(Color.rgb(105, 148, 196));
            c.drawText("AM USB Tools", side, contentBottom - dp(14), p);
        }

        private void drawMiniLogo(Canvas c, float cx, float cy) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(9, 56, 111));
            c.drawCircle(cx, cy, dp(22), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.4f));
            p.setColor(Color.rgb(46, 145, 255));
            c.drawCircle(cx, cy, dp(22), p);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(sp(11));
            p.setColor(Color.WHITE);
            c.drawText("AM", cx - dp(13), cy + dp(4), p);
            p.setStrokeWidth(dp(1.5f));
            p.setColor(Color.rgb(111, 190, 255));
            c.drawLine(cx + dp(1), cy + dp(5), cx + dp(1), cy + dp(13), p);
            c.drawCircle(cx + dp(1), cy + dp(15), dp(2), p);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(25, 91, 170));
            c.drawCircle(cx, cy, dp(22), p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2.1f));
            p.setColor(Color.rgb(214, 237, 255));
            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - dp(6), dp(4), p);
                    c.drawLine(cx, cy - dp(1), cx, cy + dp(10), p);
                    c.drawLine(cx, cy + dp(3), cx - dp(8), cy - dp(3), p);
                    c.drawLine(cx, cy + dp(3), cx + dp(8), cy - dp(3), p);
                    c.drawLine(cx, cy + dp(10), cx - dp(5), cy + dp(10), p);
                    c.drawLine(cx, cy + dp(10), cx + dp(5), cy + dp(10), p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, dp(10), p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - dp(5), dp(2), p);
                    c.drawRect(cx - dp(1.6f), cy - dp(1), cx + dp(1.6f), cy + dp(8), p);
                    break;
                case 2:
                    c.drawRect(cx - dp(10), cy - dp(9), cx + dp(10), cy + dp(9), p);
                    c.drawLine(cx - dp(6), cy - dp(3), cx + dp(6), cy - dp(3), p);
                    c.drawLine(cx - dp(6), cy + dp(3), cx + dp(6), cy + dp(3), p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - dp(10), cy - dp(10), cx + dp(10), cy + dp(10)), 35, 292, false, p);
                    c.drawLine(cx + dp(6), cy - dp(9), cx + dp(11), cy - dp(9), p);
                    c.drawLine(cx + dp(10), cy - dp(9), cx + dp(10), cy - dp(4), p);
                    break;
                case 4:
                    c.drawRoundRect(new RectF(cx - dp(11), cy - dp(8), cx + dp(11), cy + dp(9)), dp(3), dp(3), p);
                    c.drawLine(cx - dp(7), cy - dp(2), cx + dp(7), cy - dp(2), p);
                    break;
                default:
                    c.drawCircle(cx, cy, dp(5), p);
                    c.drawCircle(cx, cy, dp(11), p);
                    for (int j = 0; j < 8; j++) {
                        double a = Math.PI * 2 * j / 8.0;
                        c.drawLine(cx + (float)Math.cos(a)*dp(11), cy + (float)Math.sin(a)*dp(11),
                                cx + (float)Math.cos(a)*dp(15), cy + (float)Math.sin(a)*dp(15), p);
                    }
                    break;
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
