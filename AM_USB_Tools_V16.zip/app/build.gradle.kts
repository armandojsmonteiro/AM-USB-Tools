plugins {
    id("com.android.application")
}

android {
    namespace = "com.am.usbtools"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.am.usbtools"
        minSdk = 26
        targetSdk = 35
        versionCode = 16
        versionName = "16.0"
    }

    signingConfigs {
        create("stableTest") {
            storeFile = file("am-usb-tools-test.keystore")
            storePassword = "amusbtools"
            keyAlias = "amusbtools"
            keyPassword = "amusbtools"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableTest")
        }
    }
}
