package com.aminovacao.amclientes.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.aminovacao.amclientes.data.Database
import java.util.UUID

private data class MenuItem(val title:String,val icon:ImageVector)
private val menu = listOf(
    MenuItem("Início", Icons.Default.Home), MenuItem("Clientes", Icons.Default.People),
    MenuItem("Subscrições", Icons.Default.CreditCard), MenuItem("Configurações", Icons.Default.Settings),
    MenuItem("Gestão", Icons.Default.BusinessCenter), MenuItem("Arquivo", Icons.Default.Inventory),
    MenuItem("Histórico", Icons.Default.History), MenuItem("Catálogos", Icons.Default.Category)
)

@Composable fun AMClientesApp(context: Context) {
    val db = remember { Database(context) }
    var selected by remember { mutableStateOf("Início") }
    var companyId by remember { mutableStateOf("") }
    var companyName by remember { mutableStateOf("") }
    var showCompanies by remember { mutableStateOf(false) }

    fun ensureCompany() {
        if (companyId.isNotBlank()) return
        val id = UUID.randomUUID().toString(); val name = "Empresa 1"
        db.writableDatabase.execSQL("INSERT INTO companies(id,name,created_at) VALUES(?,?,?)", arrayOf(id,name,System.currentTimeMillis()))
        companyId=id; companyName=name
    }
    LaunchedEffect(Unit) { ensureCompany() }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF08111F),Color(0xFF123B67),Color(0xFF07101C))))){
        Column(Modifier.fillMaxSize().padding(14.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
                Text("AM Clientes", style=MaterialTheme.typography.headlineSmall, color=Color.White, modifier=Modifier.weight(1f))
                OutlinedButton(onClick={showCompanies=true}) { Text(companyName.ifBlank{"Empresa"}) }
            }
            Spacer(Modifier.height(12.dp))
            NavigationBar(containerColor=Color(0xCC0B1828)) {
                menu.take(4).forEach { item -> NavigationBarItem(selected=selected==item.title,onClick={selected=item.title},icon={Icon(item.icon,null)},label={Text(item.title)}) }
            }
            Spacer(Modifier.height(12.dp))
            Surface(Modifier.fillMaxSize(),shape=RoundedCornerShape(20.dp),color=Color(0xEE101B2A)) {
                when(selected){
                    "Início" -> Home(companyName)
                    "Clientes" -> SimpleSection("Clientes", "Clientes associados a $companyName", companyId, db)
                    "Subscrições" -> SimpleSection("Subscrições", "Subscrições da empresa selecionada", companyId, db)
                    "Configurações" -> SimpleSection("Configurações", "Configuração completa de $companyName", companyId, db)
                    "Gestão" -> SimpleSection("Gestão", "Gestão e operações de $companyName", companyId, db)
                    "Arquivo" -> SimpleSection("Arquivo", "Registos arquivados de $companyName", companyId, db)
                    "Histórico" -> SimpleSection("Histórico", "Histórico de alterações de $companyName", companyId, db)
                    "Catálogos" -> SimpleSection("Catálogos", "Equipamentos, serviços e consumíveis de $companyName", companyId, db)
                }
            }
        }
    }
    if(showCompanies) AlertDialog(onDismissRequest={showCompanies=false}, title={Text("Empresa ativa")}, text={Text("O contexto selecionado será aplicado a todos os módulos. A base de dados usa company_id em todos os dados dependentes.")}, confirmButton={TextButton(onClick={showCompanies=false}){Text("Fechar")}})
}

@Composable private fun Home(company:String){ Column(Modifier.padding(22.dp)){ Text("Início",color=Color.White,style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(8.dp)); Text("Empresa ativa: $company",color=Color.LightGray); Spacer(Modifier.height(20.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){ InfoCard("Clientes","0");InfoCard("Subscrições","0");InfoCard("Alertas","0") } } }
@Composable private fun InfoCard(a:String,b:String){Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text(a);Text(b,style=MaterialTheme.typography.headlineSmall)}}}
@Composable private fun SimpleSection(title:String,desc:String,companyId:String,db:Database){ Column(Modifier.padding(22.dp)){Text(title,color=Color.White,style=MaterialTheme.typography.headlineMedium);Text(desc,color=Color.LightGray);Spacer(Modifier.height(18.dp));Button(onClick={}){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Adicionar")};Spacer(Modifier.height(12.dp));Text("Contexto da empresa: $companyId",color=Color.Gray)}}
