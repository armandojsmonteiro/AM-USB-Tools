package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(6, 19, 37));
        window.setNavigationBarColor(Color.rgb(6, 19, 37));
        setContentView(new HomeView());
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final String[] items = {
            "Dispositivo USB",
            "Informação do dispositivo",
            "Formatar USB",
            "Backup e Restauro",
            "Ficheiros",
            "Configurações"
        };

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setOnClickListener(v -> Toast.makeText(MainActivity.this, "AM USB Tools V9", Toast.LENGTH_SHORT).show());
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth();
            final float h = getHeight();

            // Fundo ocupa integralmente a área disponível.
            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(4, 15, 31), Color.rgb(22, 73, 135), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Cabeçalho limpo, com margem segura.
            final float side = Math.max(22, w * 0.035f);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(Math.max(22, w * 0.034f));
            p.setColor(Color.WHITE);
            c.drawText("AM USB Tools", side, 45, p);

            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(Math.max(11, w * 0.018f));
            p.setColor(Color.rgb(169, 194, 222));
            c.drawText("Ferramentas USB para Android", side, 67, p);

            p.setTextSize(10);
            p.setColor(Color.rgb(112, 151, 196));
            c.drawText("V9", w - 35, 42, p);

            // Menu distribuído por grande parte do ecrã, em vez de ficar comprimido no topo.
            final float left = Math.max(14, w * 0.025f);
            final float right = w - left;
            final float menuTop = Math.max(105, h * 0.09f);
            final float bottomLimit = h - Math.max(105, h * 0.09f);
            final float total = bottomLimit - menuTop;
            final float gap = Math.max(10, Math.min(18, h * 0.012f));
            final float bh = (total - gap * (items.length - 1)) / items.length;

            for (int i = 0; i < items.length; i++) {
                final float top = menuTop + i * (bh + gap);
                r.set(left, top, right, top + bh);

                p.setShadowLayer(10, 0, 4, Color.argb(80, 0, 0, 0));
                p.setColor(Color.argb(220, 10, 31, 57));
                c.drawRoundRect(r, 18, 18, p);
                p.clearShadowLayer();

                // Barra lateral de seleção visual.
                p.setColor(Color.rgb(45, 126, 226));
                c.drawRoundRect(left, top + 18, left + 5, top + bh - 18, 3, 3, p);

                final float iconX = left + 34;
                final float iconY = top + bh / 2;
                drawIcon(c, iconX, iconY, i);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(Math.max(14, Math.min(18, w * 0.024f)));
                p.setColor(Color.rgb(242, 247, 253));
                c.drawText(items[i], left + 65, iconY + 6, p);

                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(Math.max(22, Math.min(30, w * 0.04f)));
                p.setColor(Color.rgb(129, 165, 204));
                c.drawText("›", right - 34, iconY + 9, p);
            }

            // Rodapé discreto, sem sobrepor o menu.
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(9);
            p.setColor(Color.rgb(96, 132, 174));
            c.drawText("AM USB Tools V9", side, h - 20, p);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(28, 80, 143));
            c.drawCircle(cx, cy, 17, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f);
            p.setColor(Color.rgb(194, 222, 249));

            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - 4, 4, p);
                    c.drawLine(cx, cy, cx, cy + 9, p);
                    c.drawLine(cx, cy + 3, cx - 7, cy - 3, p);
                    c.drawLine(cx, cy + 3, cx + 7, cy - 3, p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, 9, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - 5, 1.7f, p);
                    c.drawRect(cx - 1.4f, cy - 1, cx + 1.4f, cy + 7, p);
                    break;
                case 2:
                    c.drawRect(cx - 9, cy - 8, cx + 9, cy + 8, p);
                    c.drawLine(cx - 6, cy - 3, cx + 6, cy - 3, p);
                    c.drawLine(cx - 6, cy + 2, cx + 6, cy + 2, p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - 9, cy - 9, cx + 9, cy + 9), 35, 285, false, p);
                    c.drawLine(cx + 6, cy - 8, cx + 10, cy - 8, p);
                    c.drawLine(cx + 9, cy - 8, cx + 9, cy - 4, p);
                    break;
                case 4:
                    r.set(cx - 10, cy - 8, cx + 10, cy + 9);
                    c.drawRoundRect(r, 2, 2, p);
                    c.drawLine(cx - 7, cy - 3, cx + 7, cy - 3, p);
                    break;
                default:
                    c.drawCircle(cx, cy, 5, p);
                    c.drawCircle(cx, cy, 10, p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * 2 * i / 8.0;
                        float x1 = cx + (float) Math.cos(a) * 10;
                        float y1 = cy + (float) Math.sin(a) * 10;
                        float x2 = cx + (float) Math.cos(a) * 13;
                        float y2 = cy + (float) Math.sin(a) * 13;
                        c.drawLine(x1, y1, x2, y2, p);
                    }
                    break;
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
