package com.am.usbtools;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int topInset = 0;
    private int bottomInset = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(3, 15, 31));
        window.setNavigationBarColor(Color.rgb(3, 15, 31));
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);

        HomeView home = new HomeView();
        home.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = 24;
                bottomInset = 48;
            }
            v.invalidate();
            return insets;
        });
        setContentView(home);
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Path path = new Path();
        private final Bitmap appLogo = BitmapFactory.decodeResource(getResources(), R.drawable.am_usb_logo);
        private final Bitmap heroUsb = BitmapFactory.decodeResource(getResources(), R.drawable.hero_usb);
        private final String[] titles = {
                "Dispositivo USB", "Informação do dispositivo", "Formatar USB",
                "Backup e Restauro", "Ficheiros", "Configurações"
        };
        private final String[] subtitles = {
                "Detetar e gerir dispositivos", "Detalhes e especificações", "Formatar com segurança",
                "Copiar e restaurar dados", "Explorar e gerir ficheiros", "Personalizar a aplicação"
        };
        private final int[] iconColors = {
                Color.rgb(30, 111, 225), Color.rgb(35, 117, 220), Color.rgb(22, 153, 230),
                Color.rgb(16, 163, 157), Color.rgb(117, 65, 210), Color.rgb(193, 116, 35)
        };
        private float[] cardTops = new float[6];
        private float cardHeight;

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setFocusable(true);
        }

        private float u(float v) { return v * (getWidth() / 686f); }
        private float text(float v) { return u(v); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth(), h = getHeight();
            final float contentTop = topInset;
            final float contentBottom = h - bottomInset;

            // Fundo escuro premium, com brilho azul concentrado e ondas discretas.
            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(2, 11, 24), Color.rgb(8, 49, 94), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setShader(new LinearGradient(0, h * .58f, w, h,
                    Color.argb(0, 0, 110, 255), Color.argb(120, 0, 105, 255), Shader.TileMode.CLAMP));
            c.drawRect(0, h * .45f, w, h, p);
            p.setShader(null);

            final float side = u(42);
            final float headerY = contentTop + u(18);
            final float logoSize = u(62);

            // Cabeçalho exatamente no espírito do mockup aprovado: ícone à esquerda + AM azul.
            if (appLogo != null) {
                r.set(side, headerY, side + logoSize, headerY + logoSize);
                p.setAlpha(255);
                c.drawBitmap(appLogo, null, r, p);
            }
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(text(36));
            p.setColor(Color.rgb(21, 155, 255));
            final float titleX = side + logoSize + u(16);
            c.drawText("AM", titleX, headerY + u(38), p);
            final float amWidth = p.measureText("AM");
            p.setColor(Color.WHITE);
            c.drawText(" USB Tools", titleX + amWidth, headerY + u(38), p);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(text(18));
            p.setColor(Color.rgb(165, 198, 232));
            c.drawText("Ferramentas USB para Android", titleX, headerY + u(60), p);
            p.setTextSize(text(30));
            p.setColor(Color.rgb(225, 239, 255));
            c.drawText("⋮", w - u(38), headerY + u(39), p);

            // Hero realista: recorte da pen do mockup aprovado, sem inventar uma versão diferente.
            final float heroTop = headerY + u(78);
            final float heroH = u(270);
            if (heroUsb != null) {
                r.set(u(34), heroTop, w - u(34), heroTop + heroH);
                p.setAlpha(255);
                c.drawBitmap(heroUsb, null, r, p);
            }

            // Painel principal. Sem barras verticais laterais.
            final float panelLeft = u(24), panelRight = w - u(24);
            final float panelTop = heroTop + heroH - u(2);
            final float panelBottom = Math.min(contentBottom - u(70), panelTop + u(785));
            r.set(panelLeft, panelTop, panelRight, panelBottom);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(145, 2, 19, 39));
            p.setShadowLayer(u(18), 0, u(8), Color.argb(90, 0,0,0));
            c.drawRoundRect(r, u(28), u(28), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(1.3f));
            p.setColor(Color.argb(150, 43, 122, 205));
            c.drawRoundRect(r, u(28), u(28), p);
            p.setStyle(Paint.Style.FILL);

            final float innerLeft = panelLeft + u(18), innerRight = panelRight - u(18);
            final float innerTop = panelTop + u(20);
            final float gap = u(10);
            final float available = panelBottom - innerTop - u(18);
            cardHeight = Math.min(u(112), (available - gap * 5) / 6f);

            for (int i = 0; i < 6; i++) {
                float top = innerTop + i * (cardHeight + gap);
                cardTops[i] = top;
                r.set(innerLeft, top, innerRight, top + cardHeight);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(235, 2, 22, 43));
                p.setShadowLayer(u(8), 0, u(4), Color.argb(70,0,0,0));
                c.drawRoundRect(r, u(21), u(21), p);
                p.clearShadowLayer();
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(u(1));
                p.setColor(Color.argb(125, 40, 116, 190));
                c.drawRoundRect(r, u(21), u(21), p);
                p.setStyle(Paint.Style.FILL);

                final float iconX = innerLeft + u(58);
                final float iconY = top + cardHeight / 2f;
                drawIcon(c, iconX, iconY, i, iconColors[i]);

                final float copyX = innerLeft + u(120);
                final float arrowX = innerRight - u(28);
                final float maxTextW = arrowX - copyX - u(20);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(text(i == 1 ? 43 : 44));
                p.setColor(Color.rgb(248, 250, 253));
                String title = titles[i];
                while (p.measureText(title) > maxTextW && p.getTextSize() > text(16)) p.setTextSize(p.getTextSize() - text(1));
                c.drawText(title, copyX, iconY - u(4), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(text(29));
                p.setColor(Color.rgb(151, 184, 221));
                String sub = subtitles[i];
                while (p.measureText(sub) > maxTextW && p.getTextSize() > text(12)) p.setTextSize(p.getTextSize() - text(.5f));
                c.drawText(sub, copyX, iconY + u(23), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(text(42));
                p.setColor(Color.rgb(151, 202, 247));
                c.drawText("›", arrowX, iconY + u(13), p);
            }

            // Ondas no rodapé, sem atravessar os cartões.
            drawWave(c, w, contentBottom - u(93));
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(text(18));
            p.setColor(Color.rgb(157, 195, 234));
            String footer = "Simples. Seguro. Sempre consigo.";
            float tw = p.measureText(footer);
            c.drawText(footer, (w - tw) / 2f, contentBottom - u(38), p);

            p.setTextSize(text(9));
            p.setColor(Color.rgb(91, 137, 185));
            p.setLetterSpacing(.32f);
            String small = "A  L I G A Ç Ã O  E N T R E  S I  E  O  S E U  M U N D O";
            tw = p.measureText(small);
            c.drawText(small, (w - tw) / 2f, contentBottom - u(13), p);
            p.setLetterSpacing(0f);
            p.setAlpha(255);
        }

        private void drawUsbHero(Canvas c, float cx, float cy) { }

        private void drawIcon(Canvas c, float cx, float cy, int type, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setShadowLayer(u(6), 0, u(2), Color.argb(90, 0, 0, 0));
            c.drawCircle(cx, cy, u(28), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(2.4f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(235, 247, 255));
            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - u(6), u(4), p);
                    c.drawLine(cx, cy - u(2), cx, cy + u(12), p);
                    c.drawLine(cx, cy + u(5), cx - u(8), cy - u(1), p);
                    c.drawLine(cx, cy + u(5), cx + u(8), cy - u(1), p);
                    c.drawCircle(cx, cy + u(12), u(2), p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, u(10), p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - u(5), u(1.8f), p);
                    c.drawRoundRect(new RectF(cx - u(1.7f), cy - u(1), cx + u(1.7f), cy + u(7)), u(1), u(1), p);
                    break;
                case 2:
                    c.drawRoundRect(new RectF(cx - u(10), cy - u(9), cx + u(10), cy + u(9)), u(2), u(2), p);
                    c.drawLine(cx - u(6), cy - u(3), cx + u(6), cy - u(3), p);
                    c.drawLine(cx - u(6), cy + u(3), cx + u(6), cy + u(3), p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - u(10), cy - u(10), cx + u(10), cy + u(10)), 35, 290, false, p);
                    c.drawLine(cx + u(6), cy - u(8), cx + u(11), cy - u(8), p);
                    c.drawLine(cx + u(11), cy - u(8), cx + u(8), cy - u(3), p);
                    break;
                case 4:
                    c.drawRoundRect(new RectF(cx - u(11), cy - u(7), cx + u(11), cy + u(9)), u(2), u(2), p);
                    c.drawLine(cx - u(7), cy - u(2), cx + u(7), cy - u(2), p);
                    break;
                default:
                    c.drawCircle(cx, cy, u(6), p);
                    c.drawCircle(cx, cy, u(11), p);
                    for (int k = 0; k < 8; k++) {
                        double a = Math.PI * 2 * k / 8.0;
                        c.drawLine(cx + (float)Math.cos(a) * u(11), cy + (float)Math.sin(a) * u(11),
                                cx + (float)Math.cos(a) * u(15), cy + (float)Math.sin(a) * u(15), p);
                    }
                    break;
            }
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawWave(Canvas c, float w, float y) {
            path.reset();
            path.moveTo(u(52), y + u(12));
            path.cubicTo(w * .25f, y - u(10), w * .34f, y + u(23), w * .52f, y + u(4));
            path.cubicTo(w * .69f, y - u(14), w * .77f, y + u(18), w - u(52), y - u(2));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(2));
            p.setColor(Color.argb(150, 52, 143, 238));
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float x = e.getX(), y = e.getY();
            final float left = u(52), right = getWidth() - u(52);
            for (int i = 0; i < 6; i++) {
                if (y >= cardTops[i] && y <= cardTops[i] + cardHeight && x >= left && x <= right) {
                    Toast.makeText(MainActivity.this, titles[i], Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
            return true;
        }
    }
}
