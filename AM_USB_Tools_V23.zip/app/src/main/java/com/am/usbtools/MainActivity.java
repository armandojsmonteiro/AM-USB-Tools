package com.am.usbtools;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION = "com.am.usbtools.USB_PERMISSION";
    private static final int REQ_CREATE_BACKUP = 1201;
    private static final int REQ_RESTORE_BACKUP = 1202;
    private static final int REQ_FILE_TREE = 1203;

    private int topInset = 0;
    private int bottomInset = 0;
    private UsbManager usbManager;
    private PendingIntent usbPermissionIntent;
    private BroadcastReceiver usbPermissionReceiver;
    private JSONObject pendingBackup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(3, 15, 31));
        window.setNavigationBarColor(Color.rgb(3, 15, 31));
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);

        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        usbPermissionIntent = PendingIntent.getBroadcast(
                this,
                0,
                new Intent(ACTION_USB_PERMISSION).setPackage(getPackageName()),
                Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0
        );

        usbPermissionReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!ACTION_USB_PERMISSION.equals(intent.getAction())) return;
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
                String label = device != null ? safeDeviceName(device) : "dispositivo USB";
                Toast.makeText(
                        MainActivity.this,
                        granted ? "Autorização concedida: " + label : "Autorização recusada: " + label,
                        Toast.LENGTH_LONG
                ).show();
            }
        };

        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbPermissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbPermissionReceiver, filter);
        }

        HomeView home = new HomeView();
        home.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = 24;
                bottomInset = 48;
            }
            v.invalidate();
            return insets;
        });
        setContentView(home);
    }

    @Override
    protected void onDestroy() {
        if (usbPermissionReceiver != null) {
            try { unregisterReceiver(usbPermissionReceiver); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    private void showUsbDevices() {
        Map<String, UsbDevice> devices = usbManager.getDeviceList();
        if (devices.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Dispositivo USB")
                    .setMessage("Não foi detetado nenhum dispositivo USB ligado ao Android.\n\nLigue a pen, disco, leitor ou outro equipamento através de USB OTG e tente novamente.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        final List<UsbDevice> list = new ArrayList<>(devices.values());
        String[] entries = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            entries[i] = buildUsbSummary(list.get(i));
        }

        new AlertDialog.Builder(this)
                .setTitle("Dispositivos USB detetados")
                .setItems(entries, (dialog, which) -> requestUsbPermission(list.get(which)))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void requestUsbPermission(UsbDevice device) {
        if (usbManager.hasPermission(device)) {
            showUsbDetail(device, true);
            return;
        }
        usbManager.requestPermission(device, usbPermissionIntent);
    }

    private void showUsbDetail(UsbDevice device, boolean authorized) {
        new AlertDialog.Builder(this)
                .setTitle(safeDeviceName(device))
                .setMessage(buildUsbDetail(device, authorized))
                .setPositiveButton("OK", null)
                .show();
    }

    private void showDeviceInformation() {
        StringBuilder sb = new StringBuilder();
        sb.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("Fabricante: ").append(Build.MANUFACTURER).append("\n");
        sb.append("Modelo: ").append(Build.MODEL).append("\n");
        sb.append("Marca: ").append(Build.BRAND).append("\n\n");

        Map<String, UsbDevice> devices = usbManager.getDeviceList();
        sb.append("USB ligados: ").append(devices.size()).append("\n");
        if (!devices.isEmpty()) {
            for (UsbDevice device : devices.values()) {
                sb.append("• ").append(safeDeviceName(device))
                        .append(" — VID ").append(hex(device.getVendorId()))
                        .append(" / PID ").append(hex(device.getProductId()))
                        .append("\n");
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Informação do dispositivo")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
                .show();
    }

    private void showFormatInfo() {
        Map<String, UsbDevice> devices = usbManager.getDeviceList();
        String message;
        if (devices.isEmpty()) {
            message = "Não existe nenhum dispositivo USB detetado neste momento.\n\nLigue a pen ou disco USB e volte a entrar nesta opção.";
        } else {
            message = "Foram detetados " + devices.size() + " dispositivo(s) USB.\n\n" +
                    "A AM USB Tools já consegue identificar o equipamento, mas o Android não disponibiliza uma API pública genérica para formatar qualquer armazenamento USB diretamente pela aplicação.\n\n" +
                    "Vamos preparar esta área para usar o mecanismo de armazenamento permitido pelo sistema, sem correr o risco de apagar um disco errado.";
        }

        new AlertDialog.Builder(this)
                .setTitle("Formatar USB")
                .setMessage(message)
                .setPositiveButton("Escolher armazenamento", (dialog, which) -> openTreePicker())
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void openBackupMenu() {
        final String[] actions = {"Criar cópia de segurança", "Repor cópia de segurança"};
        new AlertDialog.Builder(this)
                .setTitle("Backup e Restauro")
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) createBackup();
                    else restoreBackup();
                })
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void createBackup() {
        pendingBackup = buildBackupJson();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "AM_USB_Tools_Backup.json");
        startActivityForResult(intent, REQ_CREATE_BACKUP);
    }

    private void restoreBackup() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_RESTORE_BACKUP);
    }

    private JSONObject buildBackupJson() {
        JSONObject root = new JSONObject();
        try {
            root.put("app", "AM USB Tools");
            root.put("version", 23);
            root.put("createdAt", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(new Date()));
            root.put("android", Build.VERSION.RELEASE);
            root.put("manufacturer", Build.MANUFACTURER);
            root.put("model", Build.MODEL);

            JSONArray usbArray = new JSONArray();
            for (UsbDevice device : usbManager.getDeviceList().values()) {
                JSONObject item = new JSONObject();
                item.put("name", safeDeviceName(device));
                item.put("vendorId", device.getVendorId());
                item.put("productId", device.getProductId());
                item.put("class", device.getDeviceClass());
                item.put("subclass", device.getDeviceSubclass());
                item.put("protocol", device.getDeviceProtocol());
                item.put("interfaceCount", device.getInterfaceCount());
                usbArray.put(item);
            }
            root.put("usbDevices", usbArray);
        } catch (JSONException ignored) {
            // The values above are primitive and should not fail in practice.
        }
        return root;
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_FILE_TREE);
    }

    private void openTreePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.putExtra("android.content.extra.SHOW_ADVANCED", true);
        startActivityForResult(intent, REQ_FILE_TREE);
    }

    private void openSettings() {
        new AlertDialog.Builder(this)
                .setTitle("Configurações")
                .setMessage("As definições da AM USB Tools serão adicionadas nesta área.\n\nPor agora, pode abrir as definições Android da aplicação.")
                .setPositiveButton("Definições Android", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("Fechar", null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_CREATE_BACKUP) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("Não foi possível abrir o ficheiro de destino.");
                out.write(pendingBackup.toString(2).getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Cópia de segurança criada.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Não foi possível criar a cópia: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQ_RESTORE_BACKUP) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IllegalStateException("Não foi possível ler o ficheiro.");
                BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                StringBuilder content = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) content.append(line);
                JSONObject restored = new JSONObject(content.toString());
                int count = restored.optJSONArray("usbDevices") != null ? restored.optJSONArray("usbDevices").length() : 0;
                new AlertDialog.Builder(this)
                        .setTitle("Cópia validada")
                        .setMessage("Backup da " + restored.optString("app", "AM USB Tools") +
                                "\nCriado em: " + restored.optString("createdAt", "—") +
                                "\nDispositivos registados: " + count +
                                "\n\nA estrutura da cópia está válida.")
                        .setPositiveButton("OK", null)
                        .show();
            } catch (Exception e) {
                Toast.makeText(this, "Cópia inválida ou ilegível.", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQ_FILE_TREE) {
            Toast.makeText(this, "Local selecionado: " + uri, Toast.LENGTH_SHORT).show();
        }
    }

    private String safeDeviceName(UsbDevice device) {
        String product = Build.VERSION.SDK_INT >= 21 ? device.getProductName() : null;
        if (product != null && !product.trim().isEmpty()) return product;
        return "USB VID " + hex(device.getVendorId()) + " / PID " + hex(device.getProductId());
    }

    private String buildUsbSummary(UsbDevice device) {
        return safeDeviceName(device) + "\nVID " + hex(device.getVendorId()) +
                " • PID " + hex(device.getProductId()) +
                " • Interfaces " + device.getInterfaceCount();
    }

    private String buildUsbDetail(UsbDevice device, boolean authorized) {
        StringBuilder sb = new StringBuilder();
        sb.append("Fabricante/VID: ").append(hex(device.getVendorId())).append("\n");
        sb.append("Produto/PID: ").append(hex(device.getProductId())).append("\n");
        sb.append("Classe: ").append(device.getDeviceClass()).append("\n");
        sb.append("Subclasse: ").append(device.getDeviceSubclass()).append("\n");
        sb.append("Protocolo: ").append(device.getDeviceProtocol()).append("\n");
        sb.append("Interfaces: ").append(device.getInterfaceCount()).append("\n");
        sb.append("Autorização: ").append(authorized ? "concedida" : "não concedida").append("\n\n");
        for (int i = 0; i < device.getInterfaceCount(); i++) {
            UsbInterface usbInterface = device.getInterface(i);
            sb.append("Interface ").append(i + 1)
                    .append(" — classe ").append(usbInterface.getInterfaceClass())
                    .append(", subclasse ").append(usbInterface.getInterfaceSubclass())
                    .append(", protocolo ").append(usbInterface.getInterfaceProtocol())
                    .append("\n");
        }
        return sb.toString();
    }

    private String hex(int value) {
        return String.format(Locale.US, "0x%04X", value & 0xFFFF);
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Path path = new Path();
        private final Bitmap appLogo = BitmapFactory.decodeResource(getResources(), R.drawable.am_usb_logo);
        private final Bitmap heroUsb = BitmapFactory.decodeResource(getResources(), R.drawable.hero_usb);
        private final String[] titles = {
                "Dispositivo USB", "Informação do dispositivo", "Formatar USB",
                "Backup e Restauro", "Ficheiros", "Configurações"
        };
        private final String[] subtitles = {
                "Detetar e gerir dispositivos", "Detalhes e especificações", "Formatar com segurança",
                "Copiar e restaurar dados", "Explorar e gerir ficheiros", "Personalizar a aplicação"
        };
        private final int[] iconColors = {
                Color.rgb(30, 111, 225), Color.rgb(35, 117, 220), Color.rgb(22, 153, 230),
                Color.rgb(16, 163, 157), Color.rgb(117, 65, 210), Color.rgb(193, 116, 35)
        };
        private float[] cardTops = new float[6];
        private float cardHeight;

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setFocusable(true);
        }

        private float u(float v) { return v * (getWidth() / 686f); }
        private float text(float v) { return u(v); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth(), h = getHeight();
            final float contentBottom = h - bottomInset;

            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(2, 11, 24), Color.rgb(8, 49, 94), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setShader(new LinearGradient(0, h * .58f, w, h,
                    Color.argb(0, 0, 110, 255), Color.argb(120, 0, 105, 255), Shader.TileMode.CLAMP));
            c.drawRect(0, h * .45f, w, h, p);
            p.setShader(null);

            final float side = u(42);
            final float headerY = topInset + u(18);
            final float logoSize = u(62);

            if (appLogo != null) {
                r.set(side, headerY, side + logoSize, headerY + logoSize);
                p.setAlpha(255);
                c.drawBitmap(appLogo, null, r, p);
            }
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(text(36));
            p.setColor(Color.rgb(21, 155, 255));
            final float titleX = side + logoSize + u(16);
            c.drawText("AM", titleX, headerY + u(38), p);
            final float amWidth = p.measureText("AM");
            p.setColor(Color.WHITE);
            c.drawText(" USB Tools", titleX + amWidth, headerY + u(38), p);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(text(18));
            p.setColor(Color.rgb(165, 198, 232));
            c.drawText("Ferramentas USB para Android", titleX, headerY + u(60), p);
            p.setTextSize(text(30));
            p.setColor(Color.rgb(225, 239, 255));
            c.drawText("⋮", w - u(38), headerY + u(39), p);

            final float heroTop = headerY + u(78);
            final float heroH = u(270);
            if (heroUsb != null) {
                r.set(u(34), heroTop, w - u(34), heroTop + heroH);
                p.setAlpha(255);
                c.drawBitmap(heroUsb, null, r, p);
            }

            final float panelLeft = u(24), panelRight = w - u(24);
            final float panelTop = heroTop + heroH - u(2);
            final float panelBottom = Math.min(contentBottom - u(70), panelTop + u(785));
            r.set(panelLeft, panelTop, panelRight, panelBottom);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(145, 2, 19, 39));
            p.setShadowLayer(u(18), 0, u(8), Color.argb(90, 0,0,0));
            c.drawRoundRect(r, u(28), u(28), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(1.3f));
            p.setColor(Color.argb(150, 43, 122, 205));
            c.drawRoundRect(r, u(28), u(28), p);
            p.setStyle(Paint.Style.FILL);

            final float innerLeft = panelLeft + u(18), innerRight = panelRight - u(18);
            final float innerTop = panelTop + u(20);
            final float gap = u(10);
            final float available = panelBottom - innerTop - u(18);
            cardHeight = Math.min(u(104), (available - gap * 5) / 6f);

            for (int i = 0; i < 6; i++) {
                float top = innerTop + i * (cardHeight + gap);
                cardTops[i] = top;
                r.set(innerLeft, top, innerRight, top + cardHeight);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(235, 2, 22, 43));
                p.setShadowLayer(u(8), 0, u(4), Color.argb(70,0,0,0));
                c.drawRoundRect(r, u(21), u(21), p);
                p.clearShadowLayer();
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(u(1));
                p.setColor(Color.argb(125, 40, 116, 190));
                c.drawRoundRect(r, u(21), u(21), p);
                p.setStyle(Paint.Style.FILL);

                final float iconX = innerLeft + u(58);
                final float iconY = top + cardHeight / 2f;
                drawIcon(c, iconX, iconY, i, iconColors[i]);

                final float copyX = innerLeft + u(120);
                final float arrowX = innerRight - u(28);
                final float maxTextW = arrowX - copyX - u(20);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(text(i == 1 ? 33 : 34));
                p.setColor(Color.rgb(248, 250, 253));
                String title = titles[i];
                while (p.measureText(title) > maxTextW && p.getTextSize() > text(16)) p.setTextSize(p.getTextSize() - text(1));
                c.drawText(title, copyX, iconY - u(4), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(text(22.5f));
                p.setColor(Color.rgb(151, 184, 221));
                String sub = subtitles[i];
                while (p.measureText(sub) > maxTextW && p.getTextSize() > text(12)) p.setTextSize(p.getTextSize() - text(.5f));
                c.drawText(sub, copyX, iconY + u(23), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(text(42));
                p.setColor(Color.rgb(151, 202, 247));
                c.drawText("›", arrowX, iconY + u(13), p);
            }

            drawWave(c, w, contentBottom - u(93));
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(text(18));
            p.setColor(Color.rgb(157, 195, 234));
            String footer = "Simples. Seguro. Sempre consigo.";
            float tw = p.measureText(footer);
            c.drawText(footer, (w - tw) / 2f, contentBottom - u(38), p);

            p.setTextSize(text(9));
            p.setColor(Color.rgb(91, 137, 185));
            p.setLetterSpacing(.32f);
            String small = "A  L I G A Ç Ã O  E N T R E  S I  E  O  S E U  M U N D O";
            tw = p.measureText(small);
            c.drawText(small, (w - tw) / 2f, contentBottom - u(13), p);
            p.setLetterSpacing(0f);
            p.setAlpha(255);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setShadowLayer(u(6), 0, u(2), Color.argb(90, 0, 0, 0));
            c.drawCircle(cx, cy, u(28), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(2.4f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(235, 247, 255));
            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - u(6), u(4), p);
                    c.drawLine(cx, cy - u(2), cx, cy + u(12), p);
                    c.drawLine(cx, cy + u(5), cx - u(8), cy - u(1), p);
                    c.drawLine(cx, cy + u(5), cx + u(8), cy - u(1), p);
                    c.drawCircle(cx, cy + u(12), u(2), p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, u(10), p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - u(5), u(1.8f), p);
                    c.drawRoundRect(new RectF(cx - u(1.7f), cy - u(1), cx + u(1.7f), cy + u(7)), u(1), u(1), p);
                    break;
                case 2:
                    c.drawRoundRect(new RectF(cx - u(10), cy - u(9), cx + u(10), cy + u(9)), u(2), u(2), p);
                    c.drawLine(cx - u(6), cy - u(3), cx + u(6), cy - u(3), p);
                    c.drawLine(cx - u(6), cy + u(3), cx + u(6), cy + u(3), p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - u(10), cy - u(10), cx + u(10), cy + u(10)), 35, 290, false, p);
                    c.drawLine(cx + u(6), cy - u(8), cx + u(11), cy - u(8), p);
                    c.drawLine(cx + u(11), cy - u(8), cx + u(8), cy - u(3), p);
                    break;
                case 4:
                    c.drawRoundRect(new RectF(cx - u(11), cy - u(7), cx + u(11), cy + u(9)), u(2), u(2), p);
                    c.drawLine(cx - u(7), cy - u(2), cx + u(7), cy - u(2), p);
                    break;
                default:
                    c.drawCircle(cx, cy, u(6), p);
                    c.drawCircle(cx, cy, u(11), p);
                    for (int k = 0; k < 8; k++) {
                        double a = Math.PI * 2 * k / 8.0;
                        c.drawLine(cx + (float)Math.cos(a) * u(11), cy + (float)Math.sin(a) * u(11),
                                cx + (float)Math.cos(a) * u(15), cy + (float)Math.sin(a) * u(15), p);
                    }
                    break;
            }
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawWave(Canvas c, float w, float y) {
            path.reset();
            path.moveTo(u(52), y + u(12));
            path.cubicTo(w * .25f, y - u(10), w * .34f, y + u(23), w * .52f, y + u(4));
            path.cubicTo(w * .69f, y - u(14), w * .77f, y + u(18), w - u(52), y - u(2));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u(2));
            p.setColor(Color.argb(150, 52, 143, 238));
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float x = e.getX(), y = e.getY();
            final float left = u(34), right = getWidth() - u(34);
            for (int i = 0; i < 6; i++) {
                if (y >= cardTops[i] && y <= cardTops[i] + cardHeight && x >= left && x <= right) {
                    switch (i) {
                        case 0: showUsbDevices(); break;
                        case 1: showDeviceInformation(); break;
                        case 2: showFormatInfo(); break;
                        case 3: openBackupMenu(); break;
                        case 4: openFilePicker(); break;
                        case 5: openSettings(); break;
                        default: break;
                    }
                    return true;
                }
            }
            return true;
        }
    }
}
