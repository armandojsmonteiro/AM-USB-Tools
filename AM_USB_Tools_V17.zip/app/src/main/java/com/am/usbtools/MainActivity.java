package com.am.usbtools;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int topInset = 0;
    private int bottomInset = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(3, 15, 31));
        window.setNavigationBarColor(Color.rgb(3, 15, 31));
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);

        HomeView home = new HomeView();
        home.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = 24;
                bottomInset = 48;
            }
            v.invalidate();
            return insets;
        });
        setContentView(home);
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Path path = new Path();
        private final String[] titles = {
                "Dispositivo USB", "Informação do dispositivo", "Formatar USB",
                "Backup e Restauro", "Ficheiros", "Configurações"
        };
        private final String[] subtitles = {
                "Detetar e gerir dispositivos", "Detalhes e especificações", "Formatar com segurança",
                "Copiar e restaurar dados", "Explorar e gerir ficheiros", "Personalizar a aplicação"
        };
        private final int[] iconColors = {
                Color.rgb(30, 111, 225), Color.rgb(35, 117, 220), Color.rgb(22, 153, 230),
                Color.rgb(16, 163, 157), Color.rgb(117, 65, 210), Color.rgb(193, 116, 35)
        };
        private float[] cardTops = new float[6];
        private float cardHeight;

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setFocusable(true);
        }

        private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
        private float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth(), h = getHeight();
            final float contentTop = topInset;
            final float contentBottom = h - bottomInset;

            // Fundo: azul escuro elegante, com brilho azul discreto na zona inferior.
            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(3, 16, 34), Color.rgb(16, 70, 128), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            p.setShader(new LinearGradient(0, h * .65f, w, h,
                    Color.argb(0, 20, 110, 220), Color.argb(90, 20, 110, 220), Shader.TileMode.CLAMP));
            c.drawRect(0, h * .55f, w, h, p);
            p.setShader(null);

            final float side = dp(28);
            final float headerTop = contentTop + dp(18);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(sp(28));
            p.setColor(Color.WHITE);
            c.drawText("AM USB Tools", side, headerTop + sp(28), p);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(sp(16));
            p.setColor(Color.rgb(174, 198, 226));
            c.drawText("Ferramentas USB para Android", side, headerTop + sp(51), p);

            // Herói visual: uma pen USB estilizada, sem roubar espaço aos menus.
            final float heroTop = headerTop + dp(68);
            drawUsbHero(c, w / 2f, heroTop + dp(74));

            // Grande balão central, inspirado diretamente no acabamento aprovado.
            final float panelLeft = dp(31), panelRight = w - dp(31);
            final float panelTop = heroTop + dp(132);
            final float panelBottom = Math.min(contentBottom - dp(22), panelTop + dp(900));
            r.set(panelLeft, panelTop, panelRight, panelBottom);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(108, 2, 17, 38));
            p.setShadowLayer(dp(18), 0, dp(7), Color.argb(80, 0, 0, 0));
            c.drawRoundRect(r, dp(30), dp(30), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.4f));
            p.setColor(Color.argb(125, 85, 154, 226));
            c.drawRoundRect(r, dp(30), dp(30), p);
            p.setStyle(Paint.Style.FILL);

            final float innerLeft = panelLeft + dp(21), innerRight = panelRight - dp(21);
            final float innerTop = panelTop + dp(22);
            final float available = panelBottom - innerTop - dp(22);
            cardHeight = Math.min(dp(89), (available - dp(55)) / 6f);
            final float gap = dp(11);

            for (int i = 0; i < 6; i++) {
                float top = innerTop + i * (cardHeight + gap);
                cardTops[i] = top;
                r.set(innerLeft, top, innerRight, top + cardHeight);
                p.setStyle(Paint.Style.FILL);
                p.setColor(Color.argb(222, 3, 24, 49));
                p.setShadowLayer(dp(8), 0, dp(4), Color.argb(60, 0, 0, 0));
                c.drawRoundRect(r, dp(22), dp(22), p);
                p.clearShadowLayer();
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1.0f));
                p.setColor(Color.argb(85, 76, 137, 207));
                c.drawRoundRect(r, dp(22), dp(22), p);
                p.setStyle(Paint.Style.FILL);

                final float iconX = innerLeft + dp(52);
                final float iconY = top + cardHeight / 2f;
                drawIcon(c, iconX, iconY, i, iconColors[i]);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(sp(18));
                p.setColor(Color.rgb(248, 250, 253));
                c.drawText(titles[i], innerLeft + dp(102), iconY - dp(5), p);
                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(sp(14));
                p.setColor(Color.rgb(151, 183, 218));
                c.drawText(subtitles[i], innerLeft + dp(102), iconY + dp(19), p);

                p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
                p.setTextSize(sp(39));
                p.setColor(Color.rgb(142, 190, 238));
                c.drawText("›", innerRight - dp(27), iconY + dp(12), p);
            }

            // Onda luminosa subtil no rodapé, como no mockup aprovado.
            drawWave(c, w, contentBottom - dp(74));
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(sp(13));
            p.setColor(Color.rgb(139, 183, 226));
            String footer = "Simples. Seguro. Sempre consigo.";
            float tw = p.measureText(footer);
            c.drawText(footer, (w - tw) / 2f, contentBottom - dp(24), p);

            p.setTextSize(sp(8));
            p.setColor(Color.rgb(91, 132, 177));
            c.drawText("AM USB Tools", side, contentBottom - dp(10), p);
        }

        private void drawUsbHero(Canvas c, float cx, float cy) {
            // brilho exterior
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(40, 0, 137, 255));
            p.setShadowLayer(dp(26), 0, 0, Color.argb(120, 0, 120, 255));
            c.drawOval(new RectF(cx - dp(122), cy - dp(28), cx + dp(122), cy + dp(42)), p);
            p.clearShadowLayer();

            // corpo inclinado da pen
            path.reset();
            path.moveTo(cx - dp(96), cy - dp(29));
            path.lineTo(cx + dp(42), cy - dp(54));
            path.lineTo(cx + dp(82), cy - dp(18));
            path.lineTo(cx - dp(56), cy + dp(16));
            path.close();
            p.setShader(new LinearGradient(cx - dp(100), cy - dp(45), cx + dp(90), cy + dp(5),
                    Color.rgb(52, 125, 203), Color.rgb(8, 31, 61), Shader.TileMode.CLAMP));
            p.setColor(Color.WHITE);
            c.drawPath(path, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.3f));
            p.setColor(Color.argb(160, 106, 188, 255));
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);

            // conector USB
            path.reset();
            path.moveTo(cx + dp(42), cy - dp(54));
            path.lineTo(cx + dp(90), cy - dp(45));
            path.lineTo(cx + dp(110), cy - dp(25));
            path.lineTo(cx + dp(82), cy - dp(18));
            path.close();
            p.setShader(new LinearGradient(cx + dp(35), cy - dp(58), cx + dp(110), cy - dp(20),
                    Color.LTGRAY, Color.rgb(70, 88, 105), Shader.TileMode.CLAMP));
            c.drawPath(path, p);
            p.setShader(null);

            // detalhes do conector
            p.setColor(Color.rgb(12, 31, 50));
            c.drawRoundRect(new RectF(cx + dp(76), cy - dp(43), cx + dp(91), cy - dp(36)), dp(2), dp(2), p);
            c.drawRoundRect(new RectF(cx + dp(87), cy - dp(37), cx + dp(101), cy - dp(30)), dp(2), dp(2), p);

            // marca AM
            p.setTypeface(Typeface.create("sans", Typeface.BOLD_ITALIC));
            p.setTextSize(sp(18));
            p.setColor(Color.rgb(8, 45, 86));
            c.drawText("AM", cx - dp(54), cy - dp(4), p);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type, int color) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            p.setShadowLayer(dp(6), 0, dp(2), Color.argb(90, 0, 0, 0));
            c.drawCircle(cx, cy, dp(25), p);
            p.clearShadowLayer();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2.2f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(235, 247, 255));
            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - dp(6), dp(4), p);
                    c.drawLine(cx, cy - dp(2), cx, cy + dp(12), p);
                    c.drawLine(cx, cy + dp(5), cx - dp(8), cy - dp(1), p);
                    c.drawLine(cx, cy + dp(5), cx + dp(8), cy - dp(1), p);
                    c.drawCircle(cx, cy + dp(12), dp(2), p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, dp(10), p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - dp(5), dp(1.8f), p);
                    c.drawRoundRect(new RectF(cx - dp(1.7f), cy - dp(1), cx + dp(1.7f), cy + dp(7)), dp(1), dp(1), p);
                    break;
                case 2:
                    c.drawRoundRect(new RectF(cx - dp(10), cy - dp(9), cx + dp(10), cy + dp(9)), dp(2), dp(2), p);
                    c.drawLine(cx - dp(6), cy - dp(3), cx + dp(6), cy - dp(3), p);
                    c.drawLine(cx - dp(6), cy + dp(3), cx + dp(6), cy + dp(3), p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - dp(10), cy - dp(10), cx + dp(10), cy + dp(10)), 35, 290, false, p);
                    c.drawLine(cx + dp(6), cy - dp(8), cx + dp(11), cy - dp(8), p);
                    c.drawLine(cx + dp(11), cy - dp(8), cx + dp(8), cy - dp(3), p);
                    break;
                case 4:
                    c.drawRoundRect(new RectF(cx - dp(11), cy - dp(7), cx + dp(11), cy + dp(9)), dp(2), dp(2), p);
                    c.drawLine(cx - dp(7), cy - dp(2), cx + dp(7), cy - dp(2), p);
                    break;
                default:
                    c.drawCircle(cx, cy, dp(6), p);
                    c.drawCircle(cx, cy, dp(11), p);
                    for (int k = 0; k < 8; k++) {
                        double a = Math.PI * 2 * k / 8.0;
                        c.drawLine(cx + (float)Math.cos(a) * dp(11), cy + (float)Math.sin(a) * dp(11),
                                cx + (float)Math.cos(a) * dp(15), cy + (float)Math.sin(a) * dp(15), p);
                    }
                    break;
            }
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStyle(Paint.Style.FILL);
        }

        private void drawWave(Canvas c, float w, float y) {
            path.reset();
            path.moveTo(dp(52), y + dp(12));
            path.cubicTo(w * .25f, y - dp(10), w * .34f, y + dp(23), w * .52f, y + dp(4));
            path.cubicTo(w * .69f, y - dp(14), w * .77f, y + dp(18), w - dp(52), y - dp(2));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(2));
            p.setColor(Color.argb(150, 52, 143, 238));
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float x = e.getX(), y = e.getY();
            final float left = dp(52), right = getWidth() - dp(52);
            for (int i = 0; i < 6; i++) {
                if (y >= cardTops[i] && y <= cardTops[i] + cardHeight && x >= left && x <= right) {
                    Toast.makeText(MainActivity.this, titles[i], Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
            return true;
        }
    }
}
