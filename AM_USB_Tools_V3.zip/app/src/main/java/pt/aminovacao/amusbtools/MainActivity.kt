package pt.aminovacao.amusbtools

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(10,18,30)) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(28)) }
        val header = TextView(this).apply { text="AM USB Tools"; textSize=28f; setTextColor(Color.WHITE); typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(6),dp(8),dp(6),dp(18)) }
        content.addView(header)
        section(content,"Gestão de Discos")
        card(content,"Formatar USB","Formatação de dispositivos USB com suporte a FAT16, FAT32, exFAT, NTFS e Ext4")
        card(content,"Assistente de partição","Gestão avançada de partições para dispositivos USB")
        card(content,"Limpar USB","Limpar dados e partições do dispositivo USB")
        card(content,"Backup / Restauração","Backup ou restauração de uma cópia completa do dispositivo USB")
        section(content,"Ferramentas USB")
        card(content,"Informação do USB","Consultar capacidade, sistema de ficheiros, partições e estado do dispositivo")
        card(content,"Desmontar USB","Remover o dispositivo USB de forma segura")
        section(content,"Ferramentas")
        card(content,"Relatório","Gerar um relatório das operações realizadas")
        scroll.addView(content); setContentView(scroll)
    }
    private fun section(parent: LinearLayout,title:String) { val v=TextView(this).apply{text=title;textSize=21f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD;setPadding(dp(6),dp(20),dp(6),dp(12))};parent.addView(v) }
    private fun card(parent:LinearLayout,title:String,description:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(16),dp(18),dp(16));background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(25,55,95),Color.rgb(18,31,52))).apply{cornerRadius=dp(18).toFloat()}}
        val t=TextView(this).apply{text=title;textSize=19f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD}
        val d=TextView(this).apply{text=description;textSize=14f;setTextColor(Color.rgb(215,225,238));setPadding(0,dp(7),0,0)}
        box.addView(t);box.addView(d);parent.addView(box,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{setMargins(0,0,0,dp(12))})
    }
}
