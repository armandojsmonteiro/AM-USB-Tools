plugins { id("com.android.application") }
android {
 namespace="com.am.usbtools"
 compileSdk=35
 defaultConfig { applicationId="com.am.usbtools"; minSdk=26; targetSdk=35; versionCode=4; versionName="V4" }
}
dependencies { implementation("androidx.appcompat:appcompat:1.7.0") }
