package com.am.usbtools;
import android.app.*; import android.os.*; import android.graphics.*; import android.graphics.drawable.*; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 int W=Color.rgb(245,247,250), M=Color.rgb(190,198,210);
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(22,22,22,22); r.setBackgroundResource(R.drawable.bg);
 TextView h=t("⚙  AM USB TOOLS",25,true); r.addView(h,new LinearLayout.LayoutParams(-1,64)); r.addView(t("Ferramentas profissionais para dispositivos USB",14,false));
 section(r,"GESTÃO DE DISCOS"); button(r,"Formatar USB","FAT16 • FAT32 • exFAT • NTFS • Ext2 • Ext3 • Ext4"); button(r,"Assistente de partição","Gestão avançada de partições para dispositivos USB"); button(r,"Desfragmentador USB","Otimização e verificação de unidades compatíveis"); button(r,"Limpar USB","Apagar dados e partições de um dispositivo USB"); button(r,"Backup / Restauração","Cópia completa ou restauração do dispositivo USB");
 section(r,"FERRAMENTAS DE JOGOS"); button(r,"Verificar USB","Diagnóstico e verificação do dispositivo"); button(r,"Informações USB","Capacidade, sistema de ficheiros e estado"); setContentView(r);}
 TextView t(String s,float z,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(W);v.setTextSize(z);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(8,8,8,8);return v;}
 void section(LinearLayout r,String s){TextView v=t(s,18,true);v.setPadding(8,22,8,10);r.addView(v);}
 void button(LinearLayout r,String a,String d){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,15,18,15);GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(25,31,43));g.setCornerRadius(20);c.setBackground(g);c.addView(t(a,18,true));TextView x=t(d,13,false);x.setTextColor(M);c.addView(x);c.setOnClickListener(v->Toast.makeText(this,a+" — função em desenvolvimento",Toast.LENGTH_SHORT).show());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,5);r.addView(c,p);}
}
