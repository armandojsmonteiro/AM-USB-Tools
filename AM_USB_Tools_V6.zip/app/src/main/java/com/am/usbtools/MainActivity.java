package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new HomeView());
    }

    private class HomeView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        HomeView() {
            super(MainActivity.this);
            setFocusable(true);
        }

        @Override
        protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);

            float w = getWidth();
            float h = getHeight();

            paint.setShader(new LinearGradient(
                    0, 0, w, h,
                    Color.rgb(5, 14, 29),
                    Color.rgb(19, 67, 125),
                    Shader.TileMode.CLAMP
            ));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            paint.setColor(Color.WHITE);
            paint.setTextSize(30);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            canvas.drawText("AM USB Tools", 28, 60, paint);

            paint.setColor(Color.rgb(185, 202, 224));
            paint.setTextSize(15);
            paint.setTypeface(Typeface.DEFAULT);
            canvas.drawText("Ferramentas USB para Android", 28, 88, paint);

            String[] items = {
                    "Dispositivo USB",
                    "Informação do dispositivo",
                    "Formatar USB",
                    "Backup e Restauro",
                    "Ficheiros",
                    "Configurações"
            };

            float top = 122;
            float left = 22;
            float right = w - 22;
            float height = 62;
            float gap = 13;

            for (String item : items) {
                paint.setColor(Color.rgb(15, 31, 54));
                canvas.drawRoundRect(left, top, right, top + height, 18, 18, paint);

                paint.setColor(Color.rgb(242, 246, 252));
                paint.setTextSize(17);
                paint.setTypeface(Typeface.DEFAULT_BOLD);
                canvas.drawText(item, left + 20, top + 38, paint);

                top += height + gap;
            }

            paint.setColor(Color.rgb(130, 155, 184));
            paint.setTextSize(12);
            paint.setTypeface(Typeface.DEFAULT);
            canvas.drawText("AM USB Tools V6", 28, h - 22, paint);
        }
    }
}
