plugins {
    id("com.android.application")
}

android {
    namespace = "com.am.usbtools"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.am.usbtools"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "6.0"
    }
}
