package com.am.usbtools;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Minimal exFAT formatter for a whole USB disk using the app's SCSI block layer. */
final class ExFatFormatter {
    private ExFatFormatter() {}

    static final class Result {
        final long capacityBytes;
        final long clusterCount;
        final int bytesPerCluster;
        Result(long capacityBytes, long clusterCount, int bytesPerCluster) {
            this.capacityBytes = capacityBytes;
            this.clusterCount = clusterCount;
            this.bytesPerCluster = bytesPerCluster;
        }
    }

    static Result format(UsbMassStorage disk, String label) throws IOException {
        final long totalSectors = disk.getSectorCount();
        if (totalSectors < 65536) throw new IOException("USB demasiado pequeno para exFAT.");

        final long partStart = 2048;
        final long partSectors = totalSectors - partStart;
        if (partSectors < 32768) throw new IOException("Espaço insuficiente para exFAT.");

        int spcShift = chooseSpcShift(partSectors);
        int sectorsPerCluster = 1 << spcShift;
        int bytesPerCluster = sectorsPerCluster * UsbMassStorage.SECTOR_SIZE;
        final int fatOffset = 24;
        int fatLength;
        long clusterCount;
        long heapOffset;
        while (true) {
            long provisional = partSectors - fatOffset;
            clusterCount = provisional / sectorsPerCluster;
            fatLength = (int)(((clusterCount + 2) * 4 + 511) / 512);
            heapOffset = align(fatOffset + (long) fatLength, sectorsPerCluster);
            clusterCount = (partSectors - heapOffset) / sectorsPerCluster;
            int neededFat = (int)(((clusterCount + 2) * 4 + 511) / 512);
            if (neededFat == fatLength) break;
            fatLength = neededFat;
        }
        if (clusterCount < 1024) throw new IOException("Poucos clusters para exFAT.");
        if (clusterCount > 0xFFFFFFF5L) throw new IOException("Dispositivo demasiado grande para esta implementação exFAT.");

        // Remove old partition metadata before creating the new volume.
        byte[] zeros = new byte[64 * 1024];
        long clear = Math.min(totalSectors, 4096);
        writeZeros(disk, 0, clear, zeros);

        // MBR, one partition of type 0x07 (exFAT/NTFS-style data partition).
        byte[] mbr = new byte[512];
        int p = 446;
        mbr[p] = 0; mbr[p + 1] = 0; mbr[p + 2] = 2; mbr[p + 3] = (byte) 0xFE;
        mbr[p + 4] = 0x07; mbr[p + 5] = (byte) 0xFE; mbr[p + 6] = (byte) 0xFF; mbr[p + 7] = (byte) 0xFF;
        putLe32(mbr, p + 8, partStart);
        putLe32(mbr, p + 12, Math.min(partSectors, 0xFFFFFFFFL));
        mbr[510] = 0x55; mbr[511] = (byte) 0xAA;
        disk.write10(0, mbr, 512);

        final int bootSectors = 12;
        byte[] boot = new byte[bootSectors * 512];
        byte[] sector0 = new byte[512];
        sector0[0] = (byte) 0xEB; sector0[1] = 0x76; sector0[2] = (byte) 0x90;
        System.arraycopy("EXFAT   ".getBytes(StandardCharsets.US_ASCII), 0, sector0, 3, 8);
        putLe64(sector0, 64, partStart);
        putLe64(sector0, 72, partSectors);
        putLe32(sector0, 80, fatOffset);
        putLe32(sector0, 84, fatLength);
        putLe32(sector0, 88, heapOffset);
        putLe32(sector0, 92, clusterCount);
        putLe32(sector0, 96, 2); // root directory cluster
        putLe32(sector0, 100, (int)(System.currentTimeMillis() / 1000L));
        putLe16(sector0, 104, 0x0100); // exFAT 1.00
        putLe16(sector0, 106, 0);
        sector0[108] = 9; // 512 bytes/sector
        sector0[109] = (byte) spcShift;
        sector0[110] = 1; // one FAT
        sector0[111] = (byte) 0x80;
        sector0[112] = (byte) 0xFF;
        sector0[510] = 0x55; sector0[511] = (byte) 0xAA;
        System.arraycopy(sector0, 0, boot, 0, 512);
        // Extended boot sectors contain the signature; remaining fields are reserved.
        for (int s = 1; s < 11; s++) {
            boot[s * 512 + 510] = 0x55;
            boot[s * 512 + 511] = (byte) 0xAA;
        }
        long checksum = bootChecksum(boot, 11 * 512);
        byte[] check = new byte[512];
        putLe32(check, 0, checksum);
        putLe32(check, 4, checksum);
        putLe32(check, 8, checksum);
        putLe32(check, 12, checksum);
        disk.write10(partStart, boot, boot.length);
        disk.write10(partStart + 11, check, 512);
        // Backup boot region.
        disk.write10(partStart + 12, boot, boot.length);
        disk.write10(partStart + 23, check, 512);

        // FAT: cluster 0/1 reserved, root directory cluster 2 marked EOC.
        byte[] fatSector = new byte[512];
        putLe32(fatSector, 0, 0xFFFFFFF8L);
        putLe32(fatSector, 4, 0xFFFFFFFFL);
        putLe32(fatSector, 8, 0xFFFFFFFFL);
        disk.write10(partStart + fatOffset, fatSector, 512);

        long heapStart = partStart + heapOffset;
        long bitmapBytes = (clusterCount + 7) / 8;
        long bitmapClusters = (bitmapBytes + bytesPerCluster - 1) / bytesPerCluster;
        long bitmapBytesPadded = bitmapClusters * bytesPerCluster;
        long upcaseBytes = 131072L;
        long upcaseClusters = (upcaseBytes + bytesPerCluster - 1) / bytesPerCluster;
        if (2 + bitmapClusters + upcaseClusters >= clusterCount) throw new IOException("Espaço insuficiente para metadados exFAT.");

        // Allocation bitmap: reserve clusters 2..(2+bitmapClusters+upcaseClusters-1).
        byte[] bitmap = new byte[(int)Math.min(bitmapBytesPadded, 4L * 1024 * 1024)];
        long reservedClusters = 1 + bitmapClusters + upcaseClusters; // root + bitmap + upcase
        for (long c = 2; c < 2 + reservedClusters; c++) {
            long bit = c;
            bitmap[(int)(bit >>> 3)] |= (byte)(1 << (bit & 7));
        }
        writeRepeated(disk, heapStart + (3 - 2L) * bytesPerCluster, bitmapBytesPadded, bitmap);

        // Root directory (cluster 2), including bitmap, upcase table and volume label.
        byte[] root = new byte[bytesPerCluster];
        // Allocation bitmap directory entry (0x81).
        root[0] = (byte)0x81;
        root[1] = 0;
        putLe32(root, 20, 3);
        putLe64(root, 24, bitmapBytes);
        // Upcase directory entry (0x82).
        int u = 32;
        root[u] = (byte)0x82;
        putLe32(root, u + 4, upcaseChecksum());
        putLe32(root, u + 20, (int)(3 + bitmapClusters));
        putLe64(root, u + 24, upcaseBytes);
        // Volume label entry (0x83).
        int v = 64;
        root[v] = (byte)0x83;
        String vol = normalizeLabel(label);
        root[v + 1] = (byte)vol.length();
        for (int i = 0; i < vol.length() && i < 11; i++) {
            char ch = vol.charAt(i);
            root[v + 2 + i * 2] = (byte)ch;
            root[v + 3 + i * 2] = (byte)(ch >>> 8);
        }
        disk.write10(heapStart, root, root.length);

        // Identity-compatible Unicode upcase table, stored contiguously and marked NoFatChain.
        byte[] upcase = new byte[131072];
        for (int i = 0; i < 65536; i++) {
            char c = (char)i;
            char upper = Character.toUpperCase(c);
            upcase[i * 2] = (byte)upper;
            upcase[i * 2 + 1] = (byte)(upper >>> 8);
        }
        long upcaseStart = heapStart + (4 - 2L) * bytesPerCluster;
        writeRepeated(disk, upcaseStart, upcaseClusters * (long)bytesPerCluster, upcase);

        return new Result(totalSectors * 512L, clusterCount, bytesPerCluster);
    }

    private static void writeZeros(UsbMassStorage d, long lba, long sectors, byte[] zeros) throws IOException {
        long done = 0;
        while (done < sectors) {
            int n = (int)Math.min(128, sectors - done);
            d.write10(lba + done, zeros, n * 512);
            done += n;
        }
    }

    private static void writeRepeated(UsbMassStorage d, long byteOffset, long bytes, byte[] pattern) throws IOException {
        if (bytes == 0) return;
        if (pattern.length == 0 || pattern.length % 512 != 0) throw new IOException("Padrão de escrita inválido.");
        long lba = byteOffset / 512;
        long sectors = bytes / 512;
        long pos = 0;
        while (pos < sectors) {
            int n = (int)Math.min(128, sectors - pos);
            byte[] out = new byte[n * 512];
            for (int i = 0; i < out.length; i++) out[i] = pattern[i % pattern.length];
            d.write10(lba + pos, out, out.length);
            pos += n;
        }
    }

    private static int chooseSpcShift(long partSectors) {
        // Keep cluster count well below the exFAT maximum while avoiding huge clusters on small media.
        if (partSectors < 262144) return 3;       // 4 KiB
        if (partSectors < 8388608) return 5;      // 16 KiB
        if (partSectors < 33554432) return 6;     // 32 KiB
        if (partSectors < 134217728) return 7;    // 64 KiB
        return 8;                                  // 128 KiB
    }

    private static long align(long value, long alignment) {
        return ((value + alignment - 1) / alignment) * alignment;
    }

    private static long bootChecksum(byte[] boot, int length) {
        long sum = 0;
        for (int i = 0; i < length; i++) {
            if (i == 106 || i == 107) continue;
            sum = ((sum >>> 1) | ((sum & 1) << 31)) + (boot[i] & 0xFFL);
            sum &= 0xFFFFFFFFL;
        }
        return sum;
    }

    private static int upcaseChecksum() {
        long sum = 0;
        for (int i = 0; i < 65536; i++) {
            char c = (char)i;
            char u = Character.toUpperCase(c);
            byte lo = (byte)u;
            byte hi = (byte)(u >>> 8);
            sum = ((sum >>> 1) | ((sum & 1) << 31)) + (lo & 0xFFL); sum &= 0xFFFFFFFFL;
            sum = ((sum >>> 1) | ((sum & 1) << 31)) + (hi & 0xFFL); sum &= 0xFFFFFFFFL;
        }
        return (int)sum;
    }

    private static String normalizeLabel(String label) {
        String s = label == null ? "AM_USB" : label.trim();
        if (s.isEmpty()) s = "AM_USB";
        if (s.length() > 11) s = s.substring(0, 11);
        return s;
    }

    private static void putLe16(byte[] a, int o, int v) { a[o]=(byte)v; a[o+1]=(byte)(v>>>8); }
    private static void putLe32(byte[] a, int o, long v) { a[o]=(byte)v; a[o+1]=(byte)(v>>>8); a[o+2]=(byte)(v>>>16); a[o+3]=(byte)(v>>>24); }
    private static void putLe64(byte[] a, int o, long v) { for (int i=0;i<8;i++) a[o+i]=(byte)(v >>> (8*i)); }
}
