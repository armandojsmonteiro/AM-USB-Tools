package com.am.usbtools;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int topInset = 0;
    private int bottomInset = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(6, 19, 37));
        window.setNavigationBarColor(Color.rgb(6, 19, 37));
        HomeView home = new HomeView();
        home.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            topInset = bars.top;
            bottomInset = bars.bottom;
            v.requestLayout();
            v.invalidate();
            return insets;
        });
        setContentView(home);
    }

    private class HomeView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final String[] items = {
            "Dispositivo USB",
            "Informação do dispositivo",
            "Formatar USB",
            "Backup e Restauro",
            "Ficheiros",
            "Configurações"
        };

        HomeView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setOnClickListener(v -> Toast.makeText(MainActivity.this, "AM USB Tools", Toast.LENGTH_SHORT).show());
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth();
            final float h = getHeight();
            final float contentTop = topInset;
            final float contentBottom = h - bottomInset;

            // Fundo em gradiente, mantendo a área visual completa.
            p.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(4, 15, 31), Color.rgb(24, 79, 143), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);

            // Respeita as áreas ocupadas pelo relógio e pelos botões de navegação.
            final float topSafe = contentTop + 18;
            final float side = Math.max(20, w * 0.035f);

            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            p.setTextSize(Math.max(25, Math.min(31, w * 0.042f)));
            p.setColor(Color.WHITE);
            c.drawText("AM USB Tools", side, topSafe + 2, p);

            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            p.setTextSize(Math.max(14, Math.min(18, w * 0.024f)));
            p.setColor(Color.rgb(180, 201, 225));
            c.drawText("Ferramentas USB para Android", side, topSafe + 23, p);

            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(9);
            p.setColor(Color.rgb(112, 151, 196));
            c.drawText("V11", w - 40, topSafe + 2, p);

            // Cartões mais compactos e com proporção semelhante a uma aplicação profissional.
            final float left = Math.max(24, w * 0.055f);
            final float right = w - left;
            final float menuAreaTop = topSafe + 74;
            final float menuAreaBottom = contentBottom - 54;
            final float gap = Math.max(10, Math.min(15, h * 0.010f));
            final float preferredHeight = Math.max(76, Math.min(108, h * 0.070f));
            final float available = Math.max(0, menuAreaBottom - menuAreaTop);
            final float maxMenuHeight = preferredHeight * items.length + gap * (items.length - 1);
            final float menuHeight = Math.min(available, maxMenuHeight);
            final float menuTop = menuAreaTop + Math.max(0, (available - menuHeight) * 0.18f);
            final float bh = (menuHeight - gap * (items.length - 1)) / items.length;

            for (int i = 0; i < items.length; i++) {
                final float top = menuTop + i * (bh + gap);
                r.set(left, top, right, top + bh);

                p.setShadowLayer(8, 0, 3, Color.argb(75, 0, 0, 0));
                p.setColor(Color.argb(225, 7, 27, 52));
                c.drawRoundRect(r, 18, 18, p);
                p.clearShadowLayer();

                // Pequeno detalhe lateral, sem dominar o cartão.
                p.setColor(Color.rgb(45, 126, 226));
                c.drawRoundRect(left, top + 13, left + 4, top + bh - 13, 2, 2, p);

                final float iconX = left + 32;
                final float iconY = top + bh / 2;
                drawIcon(c, iconX, iconY, i);

                p.setTypeface(Typeface.create("sans", Typeface.BOLD));
                p.setTextSize(Math.max(18, Math.min(22, w * 0.030f)));
                p.setColor(Color.rgb(246, 249, 253));
                c.drawText(items[i], left + 61, iconY + 7, p);

                p.setTypeface(Typeface.DEFAULT);
                p.setTextSize(26);
                p.setColor(Color.rgb(145, 181, 218));
                c.drawText("›", right - 31, iconY + 9, p);
            }

            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(8);
            p.setColor(Color.rgb(96, 132, 174));
            c.drawText("AM USB Tools", side, contentBottom - 18, p);
        }

        private void drawIcon(Canvas c, float cx, float cy, int type) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(29, 82, 148));
            c.drawCircle(cx, cy, 15, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.0f);
            p.setColor(Color.rgb(205, 228, 250));

            switch (type) {
                case 0:
                    c.drawCircle(cx, cy - 4, 3.5f, p);
                    c.drawLine(cx, cy, cx, cy + 8, p);
                    c.drawLine(cx, cy + 3, cx - 6, cy - 2, p);
                    c.drawLine(cx, cy + 3, cx + 6, cy - 2, p);
                    break;
                case 1:
                    c.drawCircle(cx, cy, 8, p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - 4, 1.5f, p);
                    c.drawRect(cx - 1.2f, cy - 1, cx + 1.2f, cy + 6, p);
                    break;
                case 2:
                    c.drawRect(cx - 8, cy - 7, cx + 8, cy + 7, p);
                    c.drawLine(cx - 5, cy - 2, cx + 5, cy - 2, p);
                    c.drawLine(cx - 5, cy + 2, cx + 5, cy + 2, p);
                    break;
                case 3:
                    c.drawArc(new RectF(cx - 8, cy - 8, cx + 8, cy + 8), 35, 285, false, p);
                    c.drawLine(cx + 5, cy - 7, cx + 9, cy - 7, p);
                    c.drawLine(cx + 8, cy - 7, cx + 8, cy - 3, p);
                    break;
                case 4:
                    r.set(cx - 9, cy - 7, cx + 9, cy + 8);
                    c.drawRoundRect(r, 2, 2, p);
                    c.drawLine(cx - 6, cy - 2, cx + 6, cy - 2, p);
                    break;
                default:
                    c.drawCircle(cx, cy, 4.5f, p);
                    c.drawCircle(cx, cy, 9, p);
                    for (int i = 0; i < 8; i++) {
                        double a = Math.PI * 2 * i / 8.0;
                        float x1 = cx + (float) Math.cos(a) * 9;
                        float y1 = cy + (float) Math.sin(a) * 9;
                        float x2 = cx + (float) Math.cos(a) * 12;
                        float y2 = cy + (float) Math.sin(a) * 12;
                        c.drawLine(x1, y1, x2, y2, p);
                    }
                    break;
            }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
