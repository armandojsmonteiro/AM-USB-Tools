package com.am.usbtools;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Minimal MBR + FAT32 formatter for a whole USB disk (single primary partition). */
final class Fat32Formatter {
    private Fat32Formatter() {}

    static final class Result {
        final long capacityBytes;
        final long clusterCount;
        final int bytesPerCluster;
        Result(long capacityBytes, long clusterCount, int bytesPerCluster) {
            this.capacityBytes = capacityBytes;
            this.clusterCount = clusterCount;
            this.bytesPerCluster = bytesPerCluster;
        }
    }

    static Result format(UsbMassStorage disk, String label) throws IOException {
        final long totalSectors = disk.getSectorCount();
        if (totalSectors < 131072) throw new IOException("USB demasiado pequeno para esta formatação FAT32.");
        if (totalSectors > 0x0FFFFFFFL * 32L) throw new IOException("Capacidade fora do limite suportado nesta versão.");

        final long partStart = 2048;
        final long partSectors = totalSectors - partStart;
        if (partSectors < 65536) throw new IOException("Espaço insuficiente para criar a partição.");

        int sectorsPerCluster = chooseSpc(partSectors);
        final int reserved = 32;
        final int fats = 2;
        long clusterCount;
        int fatSectors;
        while (true) {
            fatSectors = fatSectorsFor(partSectors, reserved, fats, sectorsPerCluster);
            clusterCount = (partSectors - reserved - (long) fats * fatSectors) / sectorsPerCluster;
            int next = chooseSpc(clusterCount, sectorsPerCluster);
            if (next == sectorsPerCluster) break;
            sectorsPerCluster = next;
        }
        if (clusterCount < 65525) throw new IOException("O dispositivo é demasiado pequeno para FAT32.");
        if (clusterCount > 0x0FFFFFF0L) throw new IOException("Demasiados clusters para FAT32.");

        // Start with zeros in the first 1 MiB so old partition metadata disappears.
        byte[] zeros = new byte[64 * 1024];
        long clearSectors = Math.min(partStart, 2048);
        long done = 0;
        while (done < clearSectors) {
            int sectors = (int)Math.min(128, clearSectors - done);
            disk.write10(done, zeros, sectors * UsbMassStorage.SECTOR_SIZE);
            done += sectors;
        }

        byte[] mbr = new byte[512];
        // One MBR partition entry, 0x0C FAT32 LBA, aligned at 1 MiB.
        int p = 446;
        mbr[p] = 0; mbr[p+1] = 0; mbr[p+2] = 2; mbr[p+3] = (byte)0xFE;
        mbr[p+4] = 0x0C; mbr[p+5] = (byte)0xFE; mbr[p+6] = (byte)0xFF; mbr[p+7] = (byte)0xFF;
        putLe32(mbr, p+8, partStart);
        putLe32(mbr, p+12, Math.min(partSectors, 0xFFFFFFFFL));
        mbr[510] = 0x55; mbr[511] = (byte)0xAA;
        disk.write10(0, mbr, 512);

        long fatStart = partStart + reserved;
        byte[] boot = new byte[512];
        boot[0] = (byte)0xEB; boot[1] = 0x58; boot[2] = (byte)0x90;
        byte[] oem = "MSWIN4.1".getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(oem,0,boot,3,8);
        putLe16(boot,11,512);
        boot[13]=(byte)sectorsPerCluster;
        putLe16(boot,14,reserved);
        boot[16]=(byte)fats;
        putLe16(boot,17,0);
        putLe16(boot,19,0);
        boot[21]=(byte)0xF8;
        putLe16(boot,22,0);
        putLe16(boot,24,63);
        putLe16(boot,26,255);
        putLe32(boot,28,partStart);
        putLe32(boot,32,partSectors);
        putLe32(boot,36,fatSectors);
        putLe16(boot,40,0);
        putLe16(boot,42,0);
        putLe32(boot,44,2);
        putLe16(boot,48,1);
        putLe16(boot,50,6);
        boot[64]=0x80;
        boot[66]=0x29;
        putLe32(boot,67,(int)(System.currentTimeMillis()/1000L));
        byte[] vol = normalizeLabel(label).getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(vol,0,boot,71,11);
        System.arraycopy("FAT32   ".getBytes(StandardCharsets.US_ASCII),0,boot,82,8);
        boot[510]=0x55; boot[511]=(byte)0xAA;
        disk.write10(partStart, boot, 512);

        // FSInfo sector.
        byte[] fsInfo = new byte[512];
        putLe32(fsInfo,0,0x41615252L);
        putLe32(fsInfo,484,0x61417272L);
        putLe32(fsInfo,488,0xFFFFFFFFL);
        putLe32(fsInfo,492,0xFFFFFFFFL);
        putLe32(fsInfo,508,0xAA550000L);
        disk.write10(partStart + 1, fsInfo, 512);

        // Backup boot sector.
        disk.write10(partStart + 6, boot, 512);

        byte[] fat = new byte[UsbMassStorage.SECTOR_SIZE];
        putLe32(fat,0,0x0FFFFFF8L);
        putLe32(fat,4,0x0FFFFFFFL);
        putLe32(fat,8,0x0FFFFFFFL); // root cluster 2
        for (int i=0;i<fats;i++) disk.write10(fatStart + (long)i*fatSectors, fat, 512);

        // Zero the rest of reserved/FAT start and root directory cluster.
        long rootLba = fatStart + (long)fats * fatSectors;
        byte[] root = new byte[sectorsPerCluster * 512];
        disk.write10(rootLba, root, root.length);

        // Update FSInfo free cluster count approximately.
        long free = clusterCount - 1;
        putLe32(fsInfo,488, free);
        putLe32(fsInfo,492, 3);
        disk.write10(partStart + 1, fsInfo, 512);

        return new Result(totalSectors * 512L, clusterCount, sectorsPerCluster * 512);
    }

    private static String normalizeLabel(String label) {
        String s = label == null ? "AM_USB" : label.toUpperCase();
        StringBuilder b = new StringBuilder(11);
        for (int i=0;i<s.length() && b.length()<11;i++) {
            char ch=s.charAt(i);
            if (ch < 32 || ch > 126) ch='_';
            b.append(ch);
        }
        while (b.length()<11) b.append(' ');
        return b.toString();
    }
    private static int chooseSpc(long partSectors) {
        if (partSectors < 131072) return 1;
        if (partSectors < 1048576) return 2;
        if (partSectors < 4194304) return 4;
        if (partSectors < 16777216) return 8;
        if (partSectors < 33554432) return 16;
        if (partSectors < 67108864) return 32;
        return 64;
    }
    private static int chooseSpc(long clusterCount, int current) {
        if (clusterCount > 0x0FFFFFF0L) return Math.min(128, current*2);
        return current;
    }
    private static int fatSectorsFor(long partSectors, int reserved, int fats, int spc) {
        long data = partSectors - reserved;
        long fat = ((data / spc) + 2) * 4;
        return (int)((fat + 511) / 512);
    }
    private static void putLe16(byte[] a,int o,int v){a[o]=(byte)v;a[o+1]=(byte)(v>>>8);}
    private static void putLe32(byte[] a,int o,long v){a[o]=(byte)v;a[o+1]=(byte)(v>>>8);a[o+2]=(byte)(v>>>16);a[o+3]=(byte)(v>>>24);}
}
