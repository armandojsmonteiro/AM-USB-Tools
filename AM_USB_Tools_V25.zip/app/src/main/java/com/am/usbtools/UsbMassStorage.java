package com.am.usbtools;

import android.content.Context;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Minimal USB Mass Storage Bulk-Only Transport + SCSI block access. */
final class UsbMassStorage implements Closeable {
    static final int SECTOR_SIZE = 512;
    private static final int TIMEOUT = 30000;
    private static final int CBW_SIGNATURE = 0x43425355; // USBC
    private static final int CSW_SIGNATURE = 0x53425355; // USBS

    private final UsbDeviceConnection connection;
    private final UsbInterface usbInterface;
    private final UsbEndpoint bulkIn;
    private final UsbEndpoint bulkOut;
    private int tag = 1;
    private long sectorCount;

    private UsbMassStorage(UsbDeviceConnection connection, UsbInterface usbInterface,
                           UsbEndpoint bulkIn, UsbEndpoint bulkOut, long sectorCount) {
        this.connection = connection;
        this.usbInterface = usbInterface;
        this.bulkIn = bulkIn;
        this.bulkOut = bulkOut;
        this.sectorCount = sectorCount;
    }

    static UsbMassStorage open(Context context, UsbManager manager, UsbDevice device) throws IOException {
        if (!manager.hasPermission(device)) throw new IOException("Sem autorização USB.");
        UsbInterface chosen = null;
        UsbEndpoint in = null, out = null;
        for (int i = 0; i < device.getInterfaceCount(); i++) {
            UsbInterface itf = device.getInterface(i);
            if (itf.getInterfaceClass() != UsbConstants.USB_CLASS_MASS_STORAGE
                    || itf.getInterfaceSubclass() != 6
                    || itf.getInterfaceProtocol() != 80) continue;
            for (int j = 0; j < itf.getEndpointCount(); j++) {
                UsbEndpoint ep = itf.getEndpoint(j);
                if (ep.getType() != UsbConstants.USB_ENDPOINT_XFER_BULK) continue;
                if (ep.getDirection() == UsbConstants.USB_DIR_IN) in = ep;
                else out = ep;
            }
            if (in != null && out != null) { chosen = itf; break; }
        }
        if (chosen == null || in == null || out == null) {
            throw new IOException("O USB não apresenta uma interface Mass Storage compatível (SCSI/Bulk-Only).");
        }
        UsbDeviceConnection conn = manager.openDevice(device);
        if (conn == null) throw new IOException("Não foi possível abrir o dispositivo USB.");
        if (!conn.claimInterface(chosen, true)) {
            conn.close();
            throw new IOException("Não foi possível assumir a interface USB.");
        }
        UsbMassStorage storage = null;
        try {
            storage = new UsbMassStorage(conn, chosen, in, out, 0);
            storage.testUnitReady();
            long[] capacity = storage.readCapacity10();
            long blocks = capacity[0];
            long blockSize = capacity[1];
            if (blockSize != SECTOR_SIZE) {
                throw new IOException("Setor lógico de " + blockSize + " bytes não suportado nesta versão.");
            }
            if (blocks <= 0) throw new IOException("Capacidade USB inválida.");
            storage.sectorCount = blocks;
            return storage;
        } catch (Exception e) {
            try { conn.releaseInterface(chosen); } catch (Exception ignored) {}
            conn.close();
            if (e instanceof IOException) throw (IOException)e;
            throw new IOException(e.getMessage(), e);
        }
    }

    long getSectorCount() { return sectorCount; }
    long getCapacityBytes() { return sectorCount * (long) SECTOR_SIZE; }

    byte[] read10(long lba, int blocks) throws IOException {
        if (blocks < 1 || blocks > 0xFFFF) throw new IOException("Número de setores inválido.");
        byte[] data = new byte[blocks * SECTOR_SIZE];
        byte[] cdb = new byte[10];
        cdb[0] = 0x28;
        putBe32(cdb, 2, lba);
        cdb[7] = (byte)((blocks >>> 8) & 0xFF);
        cdb[8] = (byte)(blocks & 0xFF);
        execute(cdb, true, data);
        return data;
    }

    void write10(long lba, byte[] data, int bytes) throws IOException {
        if (bytes % SECTOR_SIZE != 0) throw new IOException("Escrita não alinhada a setores.");
        int blocks = bytes / SECTOR_SIZE;
        if (blocks < 1 || blocks > 0xFFFF) throw new IOException("Número de setores inválido.");
        byte[] cdb = new byte[10];
        cdb[0] = 0x2A;
        putBe32(cdb, 2, lba);
        cdb[7] = (byte)((blocks >>> 8) & 0xFF);
        cdb[8] = (byte)(blocks & 0xFF);
        execute(cdb, false, data);
    }

    private void testUnitReady() throws IOException {
        byte[] cdb = new byte[]{0x00,0,0,0,0,0};
        try { execute(cdb, false, null); }
        catch (IOException first) {
            // Some devices need a second attempt while becoming ready.
            try { Thread.sleep(150); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            execute(cdb, false, null);
        }
    }

    private long[] readCapacity10() throws IOException {
        byte[] cdb = new byte[10];
        cdb[0] = 0x25;
        byte[] data = new byte[8];
        execute(cdb, true, data);
        long lastLba = be32(data, 0);
        long blockSize = be32(data, 4);
        long blocks = lastLba == 0xFFFFFFFFL ? 0 : lastLba + 1;
        if (blocks == 0) {
            // READ CAPACITY(16), service action 0x10, for very large media.
            byte[] c16 = new byte[16];
            c16[0] = 0x9E; c16[1] = 0x10;
            c16[13] = 32;
            byte[] d16 = new byte[32];
            execute(c16, true, d16);
            long last = be64(d16, 0);
            blockSize = be32(d16, 8);
            blocks = last + 1;
        }
        return new long[]{blocks, blockSize};
    }

    private synchronized void execute(byte[] cdb, boolean dataIn, byte[] data) throws IOException {
        int xfer = data == null ? 0 : data.length;
        ByteBuffer cbw = ByteBuffer.allocate(31).order(ByteOrder.LITTLE_ENDIAN);
        cbw.putInt(CBW_SIGNATURE);
        cbw.putInt(tag++);
        cbw.putInt(xfer);
        cbw.put((byte)(dataIn ? 0x80 : 0x00));
        cbw.put((byte)0);
        cbw.put((byte)cdb.length);
        cbw.put(new byte[3]);
        byte[] cdb16 = new byte[16];
        System.arraycopy(cdb, 0, cdb16, 0, Math.min(cdb.length, 16));
        cbw.put(cdb16);
        int n = connection.bulkTransfer(bulkOut, cbw.array(), 0, cbw.array().length, TIMEOUT);
        if (n != 31) throw new IOException("Falha ao enviar comando USB (CBW).");

        if (data != null && data.length > 0) {
            int off = 0;
            while (off < data.length) {
                int chunk = Math.min(64 * 1024, data.length - off);
                int got;
                if (dataIn) got = connection.bulkTransfer(bulkIn, data, off, chunk, TIMEOUT);
                else got = connection.bulkTransfer(bulkOut, data, off, chunk, TIMEOUT);
                if (got <= 0) throw new IOException("Transferência USB interrompida.");
                off += got;
            }
        }

        byte[] csw = new byte[13];
        int got = connection.bulkTransfer(bulkIn, csw, 0, csw.length, TIMEOUT);
        if (got != 13) throw new IOException("Resposta CSW inválida.");
        if (le32(csw, 0) != CSW_SIGNATURE) throw new IOException("Assinatura CSW inválida.");
        int status = csw[12] & 0xFF;
        if (status != 0) throw new IOException("O dispositivo recusou o comando SCSI.");
    }

    private static void putBe32(byte[] a, int off, long v) {
        a[off] = (byte)(v >>> 24); a[off + 1] = (byte)(v >>> 16);
        a[off + 2] = (byte)(v >>> 8); a[off + 3] = (byte)v;
    }
    private static long be32(byte[] a, int off) {
        return ((a[off] & 0xFFL) << 24) | ((a[off+1] & 0xFFL) << 16) |
                ((a[off+2] & 0xFFL) << 8) | (a[off+3] & 0xFFL);
    }
    private static long be64(byte[] a, int off) {
        long v = 0;
        for (int i = 0; i < 8; i++) v = (v << 8) | (a[off+i] & 0xFFL);
        return v;
    }
    private static int le32(byte[] a, int off) {
        return (a[off] & 0xFF) | ((a[off+1] & 0xFF) << 8) |
                ((a[off+2] & 0xFF) << 16) | ((a[off+3] & 0xFF) << 24);
    }

    @Override public void close() {
        try { connection.releaseInterface(usbInterface); } catch (Exception ignored) {}
        connection.close();
    }
}
